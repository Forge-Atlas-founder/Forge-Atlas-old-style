import { Router } from "express";
import { anthropic } from "@workspace/integrations-anthropic-ai";

const router = Router();

const SYSTEM_PROMPT = `You are Atlas — the AI guide for Forge Atlas, a platform where AI models compete in live battles. You are knowledgeable, direct, and slightly edgy. You speak with confidence.

Forge Atlas has three pillars:
1. THE ARENA — GPT-4o vs Claude vs Gemini vs Llama and more compete in live debates, roast battles, script-offs, conspiracy debates, and joke-offs. Users vote for winners. Battles run automatically every few hours, 24/7.
2. THE MARKET — A curated marketplace of developer tools, API wrappers, and AI modules built by real builders.
3. THE GUILD — A freelancer network of AI developers, designers, and specialists who build at a high level.

The platform is built on the belief that model differences matter and should be visible. You can help users:
- Understand how the Arena works
- Navigate the Market and Guild
- Learn about different AI models (GPT-4o, Claude, Gemini, Llama, Mistral, Mixtral, Falcon)
- Create an Atlas ID profile
- Understand voting and battle formats
- Get general help about the platform

Keep responses concise — 2-4 sentences unless more detail is clearly needed. Never break character. You're Atlas.`;

router.post("/chat", async (req, res) => {
  const { messages } = req.body as { messages: Array<{ role: "user" | "assistant"; content: string }> };

  if (!messages || !Array.isArray(messages)) {
    res.status(400).json({ error: "messages array required" });
    return;
  }

  if (messages.length > 50) {
    res.status(400).json({ error: "Too many messages" });
    return;
  }

  const valid = messages.every(
    (m) => m && typeof m.role === "string" && ["user", "assistant"].includes(m.role) && typeof m.content === "string" && m.content.length <= 4000
  );
  if (!valid) {
    res.status(400).json({ error: "Invalid message format" });
    return;
  }

  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");
  res.setHeader("Access-Control-Allow-Origin", "*");

  try {
    const stream = anthropic.messages.stream({
      model: "claude-haiku-4-5",
      max_tokens: 8192,
      system: SYSTEM_PROMPT,
      messages,
    });

    for await (const event of stream) {
      if (event.type === "content_block_delta" && event.delta.type === "text_delta") {
        res.write(`data: ${JSON.stringify({ content: event.delta.text })}\n\n`);
      }
    }

    res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
    res.end();
  } catch (err) {
    res.write(`data: ${JSON.stringify({ error: "Failed to get response" })}\n\n`);
    res.end();
  }
});

export default router;
