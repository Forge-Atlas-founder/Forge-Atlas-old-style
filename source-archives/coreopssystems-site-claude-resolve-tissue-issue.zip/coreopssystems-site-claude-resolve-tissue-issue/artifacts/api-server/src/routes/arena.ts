import { Router } from "express";
import { db } from "@workspace/db";
import { battles, votes, atlasProfiles } from "@workspace/db";
import { eq, desc, and, sql, count } from "drizzle-orm";
import { scheduleNextBattle, triggerBattleNow } from "../lib/battleOrchestrator.js";
import { seedInitialBattle, startScheduler } from "../lib/battleScheduler.js";

const router = Router();

function formatTimeAgo(date: Date): string {
  const diffMs = Date.now() - date.getTime();
  const diffMins = Math.floor(diffMs / 60_000);
  const diffHours = Math.floor(diffMins / 60);
  const diffDays = Math.floor(diffHours / 24);
  if (diffMins < 60) return `${diffMins}m ago`;
  if (diffHours < 24) return `${diffHours}h ${diffMins % 60}m ago`;
  if (diffDays === 1) return "Yesterday";
  return `${diffDays} days ago`;
}

router.get("/arena/current", async (req, res) => {
  try {
    const [live] = await db
      .select()
      .from(battles)
      .where(eq(battles.status, "live"))
      .orderBy(desc(battles.id))
      .limit(1);

    if (live) {
      res.json({ battle: live, source: "live" });
      return;
    }

    const [generating] = await db
      .select()
      .from(battles)
      .where(eq(battles.status, "generating"))
      .orderBy(desc(battles.id))
      .limit(1);

    if (generating) {
      res.json({ battle: generating, source: "generating" });
      return;
    }

    const [scheduled] = await db
      .select()
      .from(battles)
      .where(eq(battles.status, "scheduled"))
      .orderBy(battles.scheduledAt)
      .limit(1);

    res.json({ battle: scheduled ?? null, source: "scheduled" });
  } catch (err) {
    res.status(500).json({ error: "Failed to get current battle" });
  }
});

router.get("/arena/battles", async (req, res) => {
  try {
    const page = parseInt(String(req.query.page ?? "1"), 10);
    const limit = Math.min(parseInt(String(req.query.limit ?? "20"), 10), 50);
    const offset = (page - 1) * limit;

    const completed = await db
      .select()
      .from(battles)
      .where(eq(battles.status, "complete"))
      .orderBy(desc(battles.id))
      .limit(limit)
      .offset(offset);

    const formatted = completed.map((b) => ({
      ...b,
      time_label: b.completedAt ? formatTimeAgo(b.completedAt) : "Recently",
    }));

    res.json({ battles: formatted });
  } catch (err) {
    res.status(500).json({ error: "Failed to get battles" });
  }
});

router.get("/arena/battles/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id, 10);
    if (isNaN(id) || id < 1) {
      res.status(400).json({ error: "Invalid battle ID" });
      return;
    }
    const [battle] = await db
      .select()
      .from(battles)
      .where(eq(battles.id, id))
      .limit(1);

    if (!battle) {
      res.status(404).json({ error: "Battle not found" });
      return;
    }

    res.json({ battle });
  } catch (err) {
    res.status(500).json({ error: "Failed to get battle" });
  }
});

router.post("/arena/vote", async (req, res) => {
  try {
    const { battleId, atlasHandle, side } = req.body as {
      battleId: number;
      atlasHandle: string;
      side: "a" | "b";
    };

    if (!battleId || !atlasHandle || !side || !["a", "b"].includes(side)) {
      res.status(400).json({ error: "battleId, atlasHandle, and side (a|b) required" });
      return;
    }

    if (typeof atlasHandle !== "string" || atlasHandle.length > 30 || !/^[a-z0-9_]+$/.test(atlasHandle)) {
      res.status(400).json({ error: "Invalid handle format" });
      return;
    }

    const [profile] = await db
      .select()
      .from(atlasProfiles)
      .where(eq(atlasProfiles.handle, atlasHandle))
      .limit(1);

    if (!profile) {
      res.status(403).json({ error: "Atlas ID not found. Create an Atlas ID first." });
      return;
    }

    const [battle] = await db
      .select()
      .from(battles)
      .where(eq(battles.id, battleId))
      .limit(1);

    if (!battle) {
      res.status(404).json({ error: "Battle not found" });
      return;
    }

    if (battle.status !== "live") {
      res.status(400).json({ error: "Battle is not accepting votes — voting is only open while the battle is live" });
      return;
    }

    try {
      await db.insert(votes).values({ battleId, atlasHandle, side });
    } catch (insertErr: unknown) {
      const msg = insertErr instanceof Error ? insertErr.message : "";
      if (msg.includes("unique") || msg.includes("duplicate") || msg.includes("23505")) {
        res.status(409).json({ error: "Already voted in this battle" });
        return;
      }
      throw insertErr;
    }

    await db
      .update(battles)
      .set(side === "a"
        ? { votesA: sql`${battles.votesA} + 1` }
        : { votesB: sql`${battles.votesB} + 1` }
      )
      .where(eq(battles.id, battleId));

    await db
      .update(atlasProfiles)
      .set({ votesCount: sql`${atlasProfiles.votesCount} + 1` })
      .where(eq(atlasProfiles.handle, atlasHandle));

    const [updated] = await db.select({ votesA: battles.votesA, votesB: battles.votesB }).from(battles).where(eq(battles.id, battleId)).limit(1);

    res.json({ success: true, votes: updated });
  } catch (err) {
    res.status(500).json({ error: "Failed to cast vote" });
  }
});

router.get("/arena/vote/:battleId/:handle", async (req, res) => {
  try {
    const battleId = parseInt(req.params.battleId, 10);
    if (isNaN(battleId) || battleId < 1) {
      res.status(400).json({ error: "Invalid battle ID" });
      return;
    }
    const handle = req.params.handle;
    if (!handle || handle.length > 30 || !/^[a-z0-9_]+$/.test(handle)) {
      res.status(400).json({ error: "Invalid handle format" });
      return;
    }

    const [vote] = await db
      .select()
      .from(votes)
      .where(and(eq(votes.battleId, battleId), eq(votes.atlasHandle, handle)))
      .limit(1);

    res.json({ voted: vote ? vote.side : null });
  } catch (err) {
    res.status(500).json({ error: "Failed to check vote" });
  }
});

router.get("/arena/leaderboard", async (req, res) => {
  try {
    const allBattles = await db
      .select()
      .from(battles)
      .where(eq(battles.status, "complete"));

    const stats: Record<string, { wins: number; losses: number; model: string; org: string }> = {};

    const MODEL_ORGS: Record<string, string> = {
      "GPT-4o": "OpenAI",
      "Claude 3.5": "Anthropic",
      "Gemini 1.5": "Google",
      "Llama 3": "Meta",
      "Mistral": "Mistral AI",
      "Mixtral": "Mistral AI",
    };

    for (const battle of allBattles) {
      for (const modelName of [battle.modelA, battle.modelB]) {
        if (!stats[modelName]) {
          stats[modelName] = { wins: 0, losses: 0, model: modelName, org: MODEL_ORGS[modelName] ?? "" };
        }
      }
      if (battle.winnerId === "a") {
        stats[battle.modelA].wins++;
        stats[battle.modelB].losses++;
      } else if (battle.winnerId === "b") {
        stats[battle.modelB].wins++;
        stats[battle.modelA].losses++;
      }
    }

    const leaderboard = Object.values(stats)
      .map((s, i) => {
        const total = s.wins + s.losses;
        return {
          rank: 0,
          model: s.model,
          org: s.org,
          wins: s.wins,
          losses: s.losses,
          winRate: total > 0 ? Math.round((s.wins / total) * 100) : 0,
          streak: 0,
          bestFormat: "Debate",
          totalRounds: total * 3,
        };
      })
      .sort((a, b) => b.winRate - a.winRate || b.wins - a.wins)
      .map((m, i) => ({ ...m, rank: i + 1 }));

    res.json({ leaderboard });
  } catch (err) {
    res.status(500).json({ error: "Failed to get leaderboard" });
  }
});

router.get("/arena/next-battle-time", async (req, res) => {
  try {
    const [next] = await db
      .select({ scheduledAt: battles.scheduledAt })
      .from(battles)
      .where(eq(battles.status, "scheduled"))
      .orderBy(battles.scheduledAt)
      .limit(1);

    res.json({ scheduledAt: next?.scheduledAt ?? null });
  } catch (err) {
    res.status(500).json({ error: "Failed to get next battle time" });
  }
});

router.post("/arena/atlas-id", async (req, res) => {
  try {
    const { handle, displayName, avatar, favoriteModel, badges } = req.body as {
      handle: string;
      displayName: string;
      avatar: string;
      favoriteModel: string;
      badges: string[];
    };

    if (!handle || !displayName || !avatar || !favoriteModel) {
      res.status(400).json({ error: "handle, displayName, avatar, favoriteModel required" });
      return;
    }

    if (typeof handle !== "string" || handle.length > 30 || !/^[a-z0-9_]+$/.test(handle)) {
      res.status(400).json({ error: "Handle must be 1-30 lowercase alphanumeric characters or underscores" });
      return;
    }

    if (typeof displayName !== "string" || displayName.length > 50) {
      res.status(400).json({ error: "Display name too long (max 50 chars)" });
      return;
    }

    if (typeof avatar !== "string" || avatar.length > 100) {
      res.status(400).json({ error: "Invalid avatar (max 100 chars)" });
      return;
    }

    if (typeof favoriteModel !== "string" || favoriteModel.length > 50) {
      res.status(400).json({ error: "Invalid favoriteModel (max 50 chars)" });
      return;
    }

    if (badges !== undefined && badges !== null) {
      if (!Array.isArray(badges) || badges.length > 20 || !badges.every((b: unknown) => typeof b === "string" && b.length <= 30)) {
        res.status(400).json({ error: "Invalid badges (array of strings, max 20 items, each max 30 chars)" });
        return;
      }
    }

    const [existing] = await db
      .select()
      .from(atlasProfiles)
      .where(eq(atlasProfiles.handle, handle))
      .limit(1);

    if (existing) {
      res.json({ profile: existing, created: false });
      return;
    }

    const [created] = await db
      .insert(atlasProfiles)
      .values({
        handle,
        displayName,
        avatar,
        favoriteModel,
        badges: badges ?? ["early", "voter"],
      })
      .returning();

    res.json({ profile: created, created: true });
  } catch (err) {
    res.status(500).json({ error: "Failed to create Atlas ID" });
  }
});

router.get("/arena/atlas-id/:handle", async (req, res) => {
  try {
    const handle = req.params.handle;
    if (!handle || handle.length > 30 || !/^[a-z0-9_]+$/.test(handle)) {
      res.status(400).json({ error: "Invalid handle format" });
      return;
    }
    const [profile] = await db
      .select()
      .from(atlasProfiles)
      .where(eq(atlasProfiles.handle, handle))
      .limit(1);

    if (!profile) {
      res.status(404).json({ error: "Atlas ID not found" });
      return;
    }

    res.json({ profile });
  } catch (err) {
    res.status(500).json({ error: "Failed to get Atlas ID" });
  }
});

router.post("/arena/trigger", async (req, res) => {
  try {
    const { secret } = req.body as { secret?: string };
    if (secret !== process.env.ARENA_TRIGGER_SECRET && process.env.NODE_ENV === "production") {
      res.status(403).json({ error: "Forbidden" });
      return;
    }

    const [scheduled] = await db
      .select()
      .from(battles)
      .where(eq(battles.status, "scheduled"))
      .orderBy(battles.scheduledAt)
      .limit(1);

    if (!scheduled) {
      await seedInitialBattle();
      res.json({ message: "Seeded initial battle" });
      return;
    }

    triggerBattleNow(scheduled.id).catch(console.error);
    res.json({ message: "Battle triggered", battleId: scheduled.id });
  } catch (err) {
    res.status(500).json({ error: "Failed to trigger battle" });
  }
});

router.get("/arena/stats", async (req, res) => {
  try {
    const [stats] = await db.select({
      totalBattles: sql<number>`count(*) filter (where ${battles.status} = 'complete')`,
    }).from(battles);
    const [voteStats] = await db.select({ totalVotes: count() }).from(votes);
    const [profileStats] = await db.select({ total: count() }).from(atlasProfiles);

    res.json({
      totalBattles: stats?.totalBattles ?? 0,
      totalVotes: voteStats?.totalVotes ?? 0,
      atlasIdsCreated: profileStats?.total ?? 0,
    });
  } catch (err) {
    res.status(500).json({ error: "Failed to get stats" });
  }
});

export default router;
