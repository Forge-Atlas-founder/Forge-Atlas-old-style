import { Router } from "express";
import { db } from "@workspace/db";
import { battles, votes, atlasProfiles } from "@workspace/db";
import { eq, desc, sql, and, gte, lte, count } from "drizzle-orm";
import { triggerBattleNow } from "../lib/battleOrchestrator.js";
import { seedInitialBattle } from "../lib/battleScheduler.js";

const router = Router();

const ADMIN_KEY = process.env.ADMIN_KEY;

function requireAdmin(req: any, res: any, next: any) {
  if (!ADMIN_KEY) {
    res.status(503).json({ error: "Admin access not configured" });
    return;
  }
  const key = req.headers["x-admin-key"] as string;
  if (!key || key !== ADMIN_KEY) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  next();
}

router.use("/admin/:path", requireAdmin);

router.get("/admin/dashboard", async (_req, res) => {
  try {
    const [battleStats] = await db
      .select({
        total: count(),
        live: sql<number>`count(*) filter (where ${battles.status} = 'live')`,
        scheduled: sql<number>`count(*) filter (where ${battles.status} = 'scheduled')`,
        generating: sql<number>`count(*) filter (where ${battles.status} = 'generating')`,
        complete: sql<number>`count(*) filter (where ${battles.status} = 'complete')`,
        totalVotesA: sql<number>`coalesce(sum(${battles.votesA}), 0)`,
        totalVotesB: sql<number>`coalesce(sum(${battles.votesB}), 0)`,
      })
      .from(battles);

    const [voteStats] = await db
      .select({ total: count() })
      .from(votes);

    const [profileStats] = await db
      .select({
        total: count(),
        totalVotesCast: sql<number>`coalesce(sum(${atlasProfiles.votesCount}), 0)`,
      })
      .from(atlasProfiles);

    const now = new Date();
    const oneDayAgo = new Date(now.getTime() - 24 * 60 * 60 * 1000);
    const oneWeekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);

    const [votesLast24h] = await db
      .select({ total: count() })
      .from(votes)
      .where(gte(votes.createdAt, oneDayAgo));

    const [votesLastWeek] = await db
      .select({ total: count() })
      .from(votes)
      .where(gte(votes.createdAt, oneWeekAgo));

    const [profilesLast24h] = await db
      .select({ total: count() })
      .from(atlasProfiles)
      .where(gte(atlasProfiles.joinedAt, oneDayAgo));

    const recentVotes = await db
      .select({
        id: votes.id,
        battleId: votes.battleId,
        atlasHandle: votes.atlasHandle,
        side: votes.side,
        createdAt: votes.createdAt,
      })
      .from(votes)
      .orderBy(desc(votes.createdAt))
      .limit(20);

    res.json({
      battles: {
        total: battleStats.total,
        live: Number(battleStats.live),
        scheduled: Number(battleStats.scheduled),
        generating: Number(battleStats.generating),
        complete: Number(battleStats.complete),
        totalVotesA: Number(battleStats.totalVotesA),
        totalVotesB: Number(battleStats.totalVotesB),
      },
      votes: {
        total: voteStats.total,
        last24h: votesLast24h.total,
        lastWeek: votesLastWeek.total,
      },
      profiles: {
        total: profileStats.total,
        totalVotesCast: Number(profileStats.totalVotesCast),
        newLast24h: profilesLast24h.total,
      },
      recentVotes,
    });
  } catch (err) {
    res.status(500).json({ error: "Failed to load dashboard" });
  }
});

router.get("/admin/battles", async (req, res) => {
  try {
    const page = parseInt(String(req.query.page ?? "1"), 10);
    const limit = Math.min(parseInt(String(req.query.limit ?? "50"), 10), 100);
    const statusFilter = req.query.status as string | undefined;
    const offset = (page - 1) * limit;

    let query = db.select().from(battles).orderBy(desc(battles.id)).limit(limit).offset(offset);

    if (statusFilter && ["scheduled", "generating", "live", "complete"].includes(statusFilter)) {
      query = db.select().from(battles).where(eq(battles.status, statusFilter as any)).orderBy(desc(battles.id)).limit(limit).offset(offset);
    }

    const allBattles = await query;
    const [totalCount] = await db.select({ total: count() }).from(battles);

    res.json({ battles: allBattles, total: totalCount.total, page, limit });
  } catch (err) {
    res.status(500).json({ error: "Failed to get battles" });
  }
});

router.patch("/admin/battles/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id, 10);
    if (isNaN(id) || id < 1) {
      res.status(400).json({ error: "Invalid battle ID" });
      return;
    }
    const updates = req.body as Partial<{
      status: string;
      modelA: string;
      modelB: string;
      category: string;
      topic: string;
      winnerId: string | null;
      votesA: number;
      votesB: number;
      responseA: string | null;
      responseB: string | null;
      round: number;
    }>;

    const allowedFields: Record<string, any> = {};
    if (updates.status !== undefined) allowedFields.status = updates.status;
    if (updates.modelA !== undefined) allowedFields.modelA = updates.modelA;
    if (updates.modelB !== undefined) allowedFields.modelB = updates.modelB;
    if (updates.category !== undefined) allowedFields.category = updates.category;
    if (updates.topic !== undefined) allowedFields.topic = updates.topic;
    if (updates.winnerId !== undefined) allowedFields.winnerId = updates.winnerId;
    if (updates.votesA !== undefined) allowedFields.votesA = updates.votesA;
    if (updates.votesB !== undefined) allowedFields.votesB = updates.votesB;
    if (updates.responseA !== undefined) allowedFields.responseA = updates.responseA;
    if (updates.responseB !== undefined) allowedFields.responseB = updates.responseB;
    if (updates.round !== undefined) allowedFields.round = updates.round;

    if (Object.keys(allowedFields).length === 0) {
      res.status(400).json({ error: "No valid fields to update" });
      return;
    }

    const [updated] = await db
      .update(battles)
      .set(allowedFields)
      .where(eq(battles.id, id))
      .returning();

    if (!updated) {
      res.status(404).json({ error: "Battle not found" });
      return;
    }

    res.json({ battle: updated });
  } catch (err) {
    res.status(500).json({ error: "Failed to update battle" });
  }
});

router.delete("/admin/battles/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id, 10);
    if (isNaN(id) || id < 1) {
      res.status(400).json({ error: "Invalid battle ID" });
      return;
    }
    await db.delete(votes).where(eq(votes.battleId, id));
    const [deleted] = await db.delete(battles).where(eq(battles.id, id)).returning();

    if (!deleted) {
      res.status(404).json({ error: "Battle not found" });
      return;
    }

    res.json({ success: true, deleted });
  } catch (err) {
    res.status(500).json({ error: "Failed to delete battle" });
  }
});

router.post("/admin/battles/trigger", async (_req, res) => {
  try {
    const [scheduled] = await db
      .select()
      .from(battles)
      .where(eq(battles.status, "scheduled"))
      .orderBy(battles.scheduledAt)
      .limit(1);

    if (!scheduled) {
      await seedInitialBattle();
      res.json({ message: "No scheduled battle found — seeded a new one" });
      return;
    }

    triggerBattleNow(scheduled.id).catch(console.error);
    res.json({ message: "Battle triggered", battleId: scheduled.id });
  } catch (err) {
    res.status(500).json({ error: "Failed to trigger battle" });
  }
});

router.post("/admin/battles/seed", async (_req, res) => {
  try {
    await seedInitialBattle();
    res.json({ message: "New battle seeded" });
  } catch (err) {
    res.status(500).json({ error: "Failed to seed battle" });
  }
});

router.get("/admin/votes", async (req, res) => {
  try {
    const page = parseInt(String(req.query.page ?? "1"), 10);
    const limit = Math.min(parseInt(String(req.query.limit ?? "50"), 10), 100);
    const battleId = req.query.battleId ? parseInt(String(req.query.battleId), 10) : undefined;
    const offset = (page - 1) * limit;

    let query;
    if (battleId) {
      query = db.select().from(votes).where(eq(votes.battleId, battleId)).orderBy(desc(votes.createdAt)).limit(limit).offset(offset);
    } else {
      query = db.select().from(votes).orderBy(desc(votes.createdAt)).limit(limit).offset(offset);
    }

    const allVotes = await query;
    res.json({ votes: allVotes, page, limit });
  } catch (err) {
    res.status(500).json({ error: "Failed to get votes" });
  }
});

router.delete("/admin/votes/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id, 10);
    if (isNaN(id) || id < 1) {
      res.status(400).json({ error: "Invalid vote ID" });
      return;
    }

    const [vote] = await db.select().from(votes).where(eq(votes.id, id)).limit(1);
    if (!vote) {
      res.status(404).json({ error: "Vote not found" });
      return;
    }

    await db.delete(votes).where(eq(votes.id, id));

    await db
      .update(battles)
      .set(vote.side === "a"
        ? { votesA: sql`greatest(${battles.votesA} - 1, 0)` }
        : { votesB: sql`greatest(${battles.votesB} - 1, 0)` }
      )
      .where(eq(battles.id, vote.battleId));

    await db
      .update(atlasProfiles)
      .set({ votesCount: sql`greatest(${atlasProfiles.votesCount} - 1, 0)` })
      .where(eq(atlasProfiles.handle, vote.atlasHandle));

    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: "Failed to delete vote" });
  }
});

router.get("/admin/profiles", async (req, res) => {
  try {
    const page = parseInt(String(req.query.page ?? "1"), 10);
    const limit = Math.min(parseInt(String(req.query.limit ?? "50"), 10), 100);
    const offset = (page - 1) * limit;

    const profiles = await db
      .select()
      .from(atlasProfiles)
      .orderBy(desc(atlasProfiles.joinedAt))
      .limit(limit)
      .offset(offset);

    const [totalCount] = await db.select({ total: count() }).from(atlasProfiles);

    res.json({ profiles, total: totalCount.total, page, limit });
  } catch (err) {
    res.status(500).json({ error: "Failed to get profiles" });
  }
});

router.delete("/admin/profiles/:handle", async (req, res) => {
  try {
    const handle = req.params.handle;
    if (!handle || handle.length > 30 || !/^[a-z0-9_]+$/.test(handle)) {
      res.status(400).json({ error: "Invalid handle format" });
      return;
    }
    await db.delete(votes).where(eq(votes.atlasHandle, handle));
    const [deleted] = await db.delete(atlasProfiles).where(eq(atlasProfiles.handle, handle)).returning();

    if (!deleted) {
      res.status(404).json({ error: "Profile not found" });
      return;
    }

    res.json({ success: true, deleted });
  } catch (err) {
    res.status(500).json({ error: "Failed to delete profile" });
  }
});

router.patch("/admin/profiles/:handle", async (req, res) => {
  try {
    const handle = req.params.handle;
    if (!handle || handle.length > 30 || !/^[a-z0-9_]+$/.test(handle)) {
      res.status(400).json({ error: "Invalid handle format" });
      return;
    }
    const updates = req.body as Partial<{
      displayName: string;
      avatar: string;
      favoriteModel: string;
      badges: string[];
      votesCount: number;
      battlesWatched: number;
    }>;

    const allowedFields: Record<string, any> = {};
    if (updates.displayName !== undefined) allowedFields.displayName = updates.displayName;
    if (updates.avatar !== undefined) allowedFields.avatar = updates.avatar;
    if (updates.favoriteModel !== undefined) allowedFields.favoriteModel = updates.favoriteModel;
    if (updates.badges !== undefined) allowedFields.badges = updates.badges;
    if (updates.votesCount !== undefined) allowedFields.votesCount = updates.votesCount;
    if (updates.battlesWatched !== undefined) allowedFields.battlesWatched = updates.battlesWatched;

    if (Object.keys(allowedFields).length === 0) {
      res.status(400).json({ error: "No valid fields to update" });
      return;
    }

    const [updated] = await db
      .update(atlasProfiles)
      .set(allowedFields)
      .where(eq(atlasProfiles.handle, handle))
      .returning();

    if (!updated) {
      res.status(404).json({ error: "Profile not found" });
      return;
    }

    res.json({ profile: updated });
  } catch (err) {
    res.status(500).json({ error: "Failed to update profile" });
  }
});

router.get("/admin/activity", async (req, res) => {
  try {
    const days = Math.min(Math.max(parseInt(String(req.query.days ?? "7"), 10) || 7, 1), 90);
    const since = new Date(Date.now() - days * 24 * 60 * 60 * 1000);

    const dailyVotes = await db
      .select({
        day: sql<string>`date_trunc('day', ${votes.createdAt})::text`,
        total: count(),
      })
      .from(votes)
      .where(gte(votes.createdAt, since))
      .groupBy(sql`date_trunc('day', ${votes.createdAt})`)
      .orderBy(sql`date_trunc('day', ${votes.createdAt})`);

    const dailyBattles = await db
      .select({
        day: sql<string>`date_trunc('day', ${battles.createdAt})::text`,
        total: count(),
      })
      .from(battles)
      .where(gte(battles.createdAt, since))
      .groupBy(sql`date_trunc('day', ${battles.createdAt})`)
      .orderBy(sql`date_trunc('day', ${battles.createdAt})`);

    const dailySignups = await db
      .select({
        day: sql<string>`date_trunc('day', ${atlasProfiles.joinedAt})::text`,
        total: count(),
      })
      .from(atlasProfiles)
      .where(gte(atlasProfiles.joinedAt, since))
      .groupBy(sql`date_trunc('day', ${atlasProfiles.joinedAt})`)
      .orderBy(sql`date_trunc('day', ${atlasProfiles.joinedAt})`);

    res.json({ dailyVotes, dailyBattles, dailySignups });
  } catch (err) {
    res.status(500).json({ error: "Failed to get activity" });
  }
});

export default router;
