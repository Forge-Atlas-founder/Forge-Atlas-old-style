import { useState, useEffect } from "react";

export function useSpectators(base: number) {
  const [count, setCount] = useState(base);

  useEffect(() => {
    const id = setInterval(() => {
      const delta = Math.floor(Math.random() * 7) - 3;
      setCount((prev) => Math.max(base - 20, Math.min(base + 30, prev + delta)));
    }, 3000);
    return () => clearInterval(id);
  }, [base]);

  return count;
}
