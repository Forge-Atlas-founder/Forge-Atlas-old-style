import { useState, useEffect } from "react";

export function useCountdown(initialH = 2, initialM = 47, initialS = 0) {
  const [time, setTime] = useState({ h: initialH, m: initialM, s: initialS });

  useEffect(() => {
    const id = setInterval(() => {
      setTime((prev) => {
        if (prev.s > 0) return { ...prev, s: prev.s - 1 };
        if (prev.m > 0) return { ...prev, m: prev.m - 1, s: 59 };
        if (prev.h > 0) return { h: prev.h - 1, m: 59, s: 59 };
        return { h: 2, m: 47, s: 0 };
      });
    }, 1000);
    return () => clearInterval(id);
  }, []);

  const pad = (n: number) => String(n).padStart(2, "0");
  return { ...time, label: `${pad(time.h)}:${pad(time.m)}:${pad(time.s)}` };
}
