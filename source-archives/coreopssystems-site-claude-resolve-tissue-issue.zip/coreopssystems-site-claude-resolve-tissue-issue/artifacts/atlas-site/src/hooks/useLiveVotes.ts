import { useState, useEffect, useRef } from "react";

export function useLiveVotes(initialA: number, initialB: number) {
  const [votesA, setVotesA] = useState(initialA);
  const [votesB, setVotesB] = useState(initialB);
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    let canceled = false;

    const tick = () => {
      if (canceled) return;
      const delay = 3000 + Math.random() * 5000;
      timerRef.current = setTimeout(() => {
        if (canceled) return;
        const side = Math.random();
        if (side < 0.47) {
          setVotesA((v) => v + 1);
        } else if (side < 0.94) {
          setVotesB((v) => v + 1);
        } else {
          setVotesA((v) => v + 1);
          setVotesB((v) => v + 1);
        }
        tick();
      }, delay);
    };
    tick();

    return () => {
      canceled = true;
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, []);

  return { votesA, votesB, setVotesA, setVotesB };
}
