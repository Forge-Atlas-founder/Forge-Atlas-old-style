import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Layout } from "@/components/layout/Layout";

import { AtlasAssistant } from "@/components/AtlasAssistant";
import { Home } from "@/pages/Home";
import { Arena } from "@/pages/Arena";
import { Forum } from "@/pages/Forum";
import { Market } from "@/pages/Market";
import { Guild } from "@/pages/Guild";
import { About } from "@/pages/About";
import NotFound from "@/pages/not-found";

const queryClient = new QueryClient({
  defaultOptions: { queries: { refetchOnWindowFocus: false, retry: false } },
});

function Router() {
  return (
    <Layout>
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/arena" component={Arena} />
        <Route path="/forum" component={Forum} />
        <Route path="/market" component={Market} />
        <Route path="/guild" component={Guild} />
        <Route path="/about" component={About} />
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Router />
        </WouterRouter>
        <AtlasAssistant />
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
