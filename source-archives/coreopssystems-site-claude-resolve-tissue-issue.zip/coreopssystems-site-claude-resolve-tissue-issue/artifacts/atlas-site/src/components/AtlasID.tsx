import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, User, Zap, ChevronRight, Award, Shield, Star, Flame, MessageSquare, Vote, Eye, Lock } from "lucide-react";
import { Button } from "@/components/ui/button";

const MODELS = ["GPT-4o", "Claude 3.5", "Gemini 1.5", "Llama 3", "Mistral", "Mixtral"];

const AVATARS = [
  { id: "A", bg: "bg-primary/20", border: "border-primary/40", text: "text-primary" },
  { id: "G", bg: "bg-blue-500/20", border: "border-blue-500/40", text: "text-blue-400" },
  { id: "C", bg: "bg-purple-500/20", border: "border-purple-500/40", text: "text-purple-400" },
  { id: "L", bg: "bg-red-500/20", border: "border-red-500/40", text: "text-red-400" },
  { id: "M", bg: "bg-green-500/20", border: "border-green-500/40", text: "text-green-400" },
  { id: "F", bg: "bg-orange-500/20", border: "border-orange-500/40", text: "text-orange-400" },
];

const BADGES = [
  { id: "early", label: "Early Adopter", icon: Star, desc: "Joined Season 1" },
  { id: "voter", label: "Voter", icon: Zap, desc: "Cast your first vote" },
  { id: "watcher", label: "Arena Watcher", icon: Shield, desc: "Witnessed 5 battles" },
  { id: "builder", label: "Builder", icon: Flame, desc: "Listed in the Market" },
];

export interface AtlasProfile {
  handle: string;
  displayName: string;
  avatar: string;
  favoriteModel: string;
  badges: string[];
  joinedAt: string;
  votesCount: number;
}

function getProfile(): AtlasProfile | null {
  try {
    const raw = localStorage.getItem("atlas_id");
    return raw ? JSON.parse(raw) : null;
  } catch { return null; }
}

function saveProfile(p: AtlasProfile) {
  localStorage.setItem("atlas_id", JSON.stringify(p));
}

// ── Creation flow ─────────────────────────────────────────────────────────────
function CreateFlow({ onDone }: { onDone: (p: AtlasProfile) => void }) {
  const [step, setStep] = useState(0);
  const [displayName, setDisplayName] = useState("");
  const [handle, setHandle] = useState("");
  const [avatar, setAvatar] = useState(AVATARS[0].id);
  const [favoriteModel, setFavoriteModel] = useState("");

  const handleInput = (val: string) => {
    setDisplayName(val);
    setHandle(val.toLowerCase().replace(/[^a-z0-9_]/g, "").slice(0, 20));
  };

  const finish = () => {
    const profile: AtlasProfile = {
      handle: handle || "atlas_user",
      displayName: displayName || "Atlas Member",
      avatar,
      favoriteModel: favoriteModel || "GPT-4o",
      badges: ["early", "voter"],
      joinedAt: new Date().toISOString(),
      votesCount: 0,
    };
    saveProfile(profile);
    onDone(profile);
  };

  return (
    <div className="space-y-6">
      <AnimatePresence mode="wait">
        {step === 0 && (
          <motion.div key="step0" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
            <p className="text-xs font-display tracking-[0.25em] text-primary uppercase mb-5">Step 1 of 3 — Identity</p>
            <h3 className="text-xl font-display font-bold text-white uppercase mb-6">What's your name?</h3>
            <input
              autoFocus
              placeholder="DISPLAY NAME"
              value={displayName}
              onChange={(e) => handleInput(e.target.value)}
              maxLength={32}
              className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3.5 text-white font-display tracking-widest text-sm placeholder:text-white/20 focus:outline-none focus:border-primary/60 transition-colors mb-3"
            />
            {handle && (
              <p className="text-xs text-muted-foreground font-display tracking-widest">@{handle}</p>
            )}
            <Button className="w-full mt-6" onClick={() => setStep(1)} disabled={!displayName.trim()}>
              Continue <ChevronRight className="ml-2 w-4 h-4" />
            </Button>
          </motion.div>
        )}
        {step === 1 && (
          <motion.div key="step1" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
            <p className="text-xs font-display tracking-[0.25em] text-primary uppercase mb-5">Step 2 of 3 — Avatar</p>
            <h3 className="text-xl font-display font-bold text-white uppercase mb-6">Pick your avatar</h3>
            <div className="grid grid-cols-3 gap-3 mb-6">
              {AVATARS.map((a) => (
                <button
                  key={a.id}
                  onClick={() => setAvatar(a.id)}
                  className={`aspect-square rounded-2xl border-2 ${a.bg} ${avatar === a.id ? a.border + " scale-105" : "border-white/10"} flex items-center justify-center transition-all duration-200`}
                >
                  <span className={`text-3xl font-display font-bold ${a.text}`}>{a.id}</span>
                </button>
              ))}
            </div>
            <div className="flex gap-3">
              <Button variant="outline" onClick={() => setStep(0)} className="flex-1">Back</Button>
              <Button onClick={() => setStep(2)} className="flex-1">Continue <ChevronRight className="ml-2 w-4 h-4" /></Button>
            </div>
          </motion.div>
        )}
        {step === 2 && (
          <motion.div key="step2" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
            <p className="text-xs font-display tracking-[0.25em] text-primary uppercase mb-5">Step 3 of 3 — Allegiance</p>
            <h3 className="text-xl font-display font-bold text-white uppercase mb-6">Your favorite model?</h3>
            <div className="grid grid-cols-2 gap-2.5 mb-6">
              {MODELS.map((m) => (
                <button
                  key={m}
                  onClick={() => setFavoriteModel(m)}
                  className={`py-3 px-4 rounded-xl border text-xs font-display tracking-widest uppercase transition-all ${favoriteModel === m ? "border-primary text-primary bg-primary/10" : "border-white/10 text-muted-foreground hover:border-white/25"}`}
                >
                  {m}
                </button>
              ))}
            </div>
            <div className="flex gap-3">
              <Button variant="outline" onClick={() => setStep(1)} className="flex-1">Back</Button>
              <Button onClick={finish} className="flex-1" disabled={!favoriteModel}>Create Atlas ID</Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

// ── Profile card ──────────────────────────────────────────────────────────────
function ProfileCard({ profile, onReset }: { profile: AtlasProfile; onReset: () => void }) {
  const av = AVATARS.find((a) => a.id === profile.avatar) ?? AVATARS[0];
  const joined = new Date(profile.joinedAt).toLocaleDateString("en-US", { month: "long", year: "numeric" });

  return (
    <div className="space-y-5">
      {/* Avatar + name */}
      <div className="flex items-center gap-4">
        <div className={`w-16 h-16 rounded-2xl ${av.bg} border-2 ${av.border} flex items-center justify-center shrink-0`}>
          <span className={`text-2xl font-display font-bold ${av.text}`}>{av.id}</span>
        </div>
        <div>
          <p className="text-lg font-display font-bold text-white">{profile.displayName}</p>
          <p className="text-xs font-display text-muted-foreground tracking-widest">@{profile.handle}</p>
          <p className="text-[10px] font-display text-primary/70 tracking-widest uppercase mt-0.5">Member since {joined}</p>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-2 border-t border-b border-white/5 py-4">
        {[
          { label: "Votes", value: profile.votesCount },
          { label: "Battles Watched", value: 0 },
          { label: "Rank", value: "#—" },
        ].map((s) => (
          <div key={s.label} className="text-center">
            <p className="text-lg font-display font-bold text-primary">{s.value}</p>
            <p className="text-[9px] font-display text-muted-foreground tracking-widest uppercase">{s.label}</p>
          </div>
        ))}
      </div>

      {/* Favorite model */}
      <div className="flex items-center justify-between">
        <span className="text-[10px] font-display text-muted-foreground tracking-widest uppercase">Allegiance</span>
        <span className="text-xs font-display font-bold text-primary border border-primary/30 bg-primary/10 px-3 py-1 rounded-full">{profile.favoriteModel}</span>
      </div>

      {/* Badges */}
      <div>
        <p className="text-[10px] font-display text-muted-foreground tracking-widest uppercase mb-3">Badges</p>
        <div className="grid grid-cols-2 gap-2">
          {BADGES.filter((b) => profile.badges.includes(b.id)).map((b) => (
            <div key={b.id} className="flex items-center gap-2 bg-white/4 border border-white/8 rounded-xl px-3 py-2.5">
              <b.icon className="w-3.5 h-3.5 text-primary shrink-0" />
              <div>
                <p className="text-[10px] font-display font-bold text-white">{b.label}</p>
                <p className="text-[9px] text-muted-foreground">{b.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      <button onClick={onReset} className="text-[10px] text-muted-foreground hover:text-white/40 transition-colors font-display tracking-widest uppercase w-full text-center">
        Reset Atlas ID
      </button>
    </div>
  );
}

// ── Main component ─────────────────────────────────────────────────────────────
export function AtlasIDButton() {
  const [open, setOpen] = useState(false);
  const [profile, setProfile] = useState<AtlasProfile | null>(null);

  useEffect(() => { setProfile(getProfile()); }, []);

  const handleDone = (p: AtlasProfile) => setProfile(p);
  const handleReset = () => { localStorage.removeItem("atlas_id"); setProfile(null); };

  return (
    <>
      <button
        data-atlas-id-trigger
        onClick={() => setOpen(true)}
        className="flex items-center gap-2 text-xs font-display tracking-[0.2em] uppercase text-white/60 hover:text-primary border border-white/10 hover:border-primary/40 px-3.5 py-2 rounded-full transition-all duration-200"
      >
        <User className="w-3.5 h-3.5" />
        {profile ? `@${profile.handle}` : "Atlas ID"}
      </button>

      <AnimatePresence>
        {open && (
          <>
            <motion.div
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50"
              onClick={() => setOpen(false)}
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              transition={{ duration: 0.2 }}
              className="fixed inset-0 z-50 flex items-center justify-center p-6 pointer-events-none"
            >
              <div className="w-full max-w-sm bg-[#111] border border-white/10 rounded-2xl p-6 shadow-2xl pointer-events-auto max-h-[90vh] overflow-y-auto">
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center gap-2.5">
                    <div className="w-7 h-7 rounded-lg bg-primary/15 flex items-center justify-center">
                      <Award className="w-4 h-4 text-primary" />
                    </div>
                    <span className="text-sm font-display font-bold text-white uppercase tracking-wide">Atlas ID</span>
                  </div>
                  <button onClick={() => setOpen(false)} className="text-white/25 hover:text-white/60 transition-colors">
                    <X className="w-4 h-4" />
                  </button>
                </div>

                {profile ? (
                  <ProfileCard profile={profile} onReset={handleReset} />
                ) : (
                  <>
                    <div className="mb-6 p-3 rounded-xl bg-white/[0.02] border border-white/5">
                      <p className="text-[9px] font-display tracking-[0.3em] text-primary uppercase font-bold mb-3">Atlas ID Unlocks</p>
                      <div className="grid grid-cols-2 gap-2">
                        {[
                          { icon: Vote, label: "Vote in battles" },
                          { icon: MessageSquare, label: "Live battle chat" },
                          { icon: Eye, label: "Full forum threads" },
                          { icon: Star, label: "Earn badges" },
                        ].map((item) => (
                          <div key={item.label} className="flex items-center gap-2 text-[10px] text-white/30">
                            <item.icon className="w-3 h-3 text-primary/60" />
                            <span>{item.label}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                    <CreateFlow onDone={handleDone} />
                  </>
                )}
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}
