import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ThumbsUp, Eye, Zap, MessageSquare, Trophy, Flame, UserPlus } from "lucide-react";

const HANDLES = [
  "@k_builds", "@mdev_", "@atlas_ux", "@sys_arc", "@nova_coder", "@zk_dev",
  "@pixel_forge", "@quantum_", "@neo_smith", "@byte_rider", "@flux_eng",
  "@signal_op", "@dark_matter", "@orbit_dev", "@prime_arc", "@data_monk",
  "@void_runner", "@cipher_x", "@echo_dev", "@neural_net", "@ghost_ops",
];

const VOTE_EVENTS = [
  { model: "GPT-4o", color: "text-emerald-400" },
  { model: "Claude", color: "text-violet-400" },
];

const EVENT_TYPES = [
  { type: "vote", icon: ThumbsUp, weight: 40 },
  { type: "join", icon: Eye, weight: 20 },
  { type: "react", icon: Zap, weight: 15 },
  { type: "comment", icon: MessageSquare, weight: 10 },
  { type: "streak", icon: Flame, weight: 8 },
  { type: "signup", icon: UserPlus, weight: 7 },
];

function pickWeighted<T extends { weight: number }>(items: T[]): T {
  const total = items.reduce((s, i) => s + i.weight, 0);
  let r = Math.random() * total;
  for (const item of items) {
    r -= item.weight;
    if (r <= 0) return item;
  }
  return items[0];
}

function generateEvent(id: number) {
  const eventType = pickWeighted(EVENT_TYPES);
  const handle = HANDLES[Math.floor(Math.random() * HANDLES.length)];
  const vote = VOTE_EVENTS[Math.floor(Math.random() * 2)];

  switch (eventType.type) {
    case "vote":
      return { id, icon: eventType.icon, text: `${handle} voted for`, highlight: vote.model, highlightColor: vote.color, time: "just now" };
    case "join":
      return { id, icon: eventType.icon, text: `${handle} is watching the battle`, highlight: "", highlightColor: "", time: "just now" };
    case "react":
      return { id, icon: eventType.icon, text: `${handle} reacted to ${vote.model}'s response`, highlight: "", highlightColor: vote.color, time: "just now" };
    case "comment":
      return { id, icon: eventType.icon, text: `${handle} said "${["That hit different", "GPT cooked here", "Claude's being philosophical again", "This round goes to Claude", "Brutal response", "This is peak AI content", "Mixtral would've won this", "Llama would go harder"][Math.floor(Math.random() * 8)]}"`, highlight: "", highlightColor: "", time: "just now" };
    case "streak":
      return { id, icon: eventType.icon, text: `${vote.model} is on a`, highlight: `${Math.floor(Math.random() * 4) + 2}-win streak`, highlightColor: "text-primary", time: "just now" };
    case "signup":
      return { id, icon: eventType.icon, text: `${handle} created an Atlas ID`, highlight: "", highlightColor: "", time: "just now" };
    default:
      return { id, icon: eventType.icon, text: `${handle} joined`, highlight: "", highlightColor: "", time: "just now" };
  }
}

export function LiveFeed() {
  const [events, setEvents] = useState<ReturnType<typeof generateEvent>[]>([]);
  const idRef = useRef(0);

  useEffect(() => {
    const initial = Array.from({ length: 4 }, () => generateEvent(idRef.current++));
    setEvents(initial);

    const addEvent = () => {
      const evt = generateEvent(idRef.current++);
      setEvents((prev) => [evt, ...prev].slice(0, 8));
    };

    const id = setInterval(addEvent, 2500 + Math.random() * 2000);
    return () => clearInterval(id);
  }, []);

  return (
    <div className="space-y-0.5 overflow-hidden">
      <AnimatePresence initial={false}>
        {events.map((evt) => (
          <motion.div
            key={evt.id}
            initial={{ opacity: 0, x: -20, height: 0 }}
            animate={{ opacity: 1, x: 0, height: "auto" }}
            exit={{ opacity: 0, x: 20, height: 0 }}
            transition={{ duration: 0.3 }}
            className="flex items-center gap-2 py-1.5 text-[10px] font-display tracking-wide"
          >
            <evt.icon className="w-3 h-3 text-white/15 shrink-0" />
            <span className="text-white/30 truncate">
              {evt.text}
              {evt.highlight && (
                <span className={`${evt.highlightColor || "text-primary"} font-bold ml-1`}>{evt.highlight}</span>
              )}
            </span>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}

export function LiveToast() {
  const [toast, setToast] = useState<ReturnType<typeof generateEvent> | null>(null);
  const [visible, setVisible] = useState(false);
  const idRef = useRef(100);
  const hideTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    let canceled = false;

    const show = () => {
      if (canceled) return;
      const evt = generateEvent(idRef.current++);
      setToast(evt);
      setVisible(true);
      if (hideTimerRef.current) clearTimeout(hideTimerRef.current);
      hideTimerRef.current = setTimeout(() => {
        if (!canceled) setVisible(false);
      }, 3500);
    };

    const id = setInterval(show, 8000 + Math.random() * 7000);
    const initialTimeout = setTimeout(show, 4000);
    return () => {
      canceled = true;
      clearInterval(id);
      clearTimeout(initialTimeout);
      if (hideTimerRef.current) clearTimeout(hideTimerRef.current);
    };
  }, []);

  return (
    <div className="fixed bottom-6 left-6 z-40 pointer-events-none">
      <AnimatePresence>
        {visible && toast && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 10, scale: 0.95 }}
            transition={{ duration: 0.3, ease: "easeOut" }}
            className="bg-[#111] border border-white/10 rounded-xl px-4 py-3 flex items-center gap-3 shadow-2xl max-w-xs"
          >
            <div className="w-6 h-6 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
              <toast.icon className="w-3 h-3 text-primary" />
            </div>
            <div>
              <p className="text-[10px] text-white/50 font-display tracking-wide leading-relaxed">
                {toast.text}
                {toast.highlight && (
                  <span className={`${toast.highlightColor || "text-primary"} font-bold ml-1`}>{toast.highlight}</span>
                )}
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
