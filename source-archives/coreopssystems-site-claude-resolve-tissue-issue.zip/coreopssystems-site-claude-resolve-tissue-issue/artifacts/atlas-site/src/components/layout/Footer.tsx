import { Link } from "wouter";

export function Footer() {
  return (
    <footer className="bg-card border-t border-white/5 pt-16 pb-8 px-6">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-5 gap-12 mb-16">
        <div className="md:col-span-2">
          <Link href="/" className="flex items-center gap-2.5 mb-5">
            <svg viewBox="0 0 100 100" className="w-8 h-8">
              <rect width="100" height="100" fill="#0a0a0a"/>
              <path d="M50 12 L18 88 H34 L42 66 H58 L66 88 H82 L50 12 Z" fill="#D4A843"/>
              <path d="M45 52 H55 L50 38 Z" fill="#0a0a0a"/>
            </svg>
            <div className="flex flex-col leading-none">
              <span className="font-display text-lg font-bold tracking-[0.2em] text-white">FORGE ATLAS</span>
              <span className="text-[9px] tracking-[0.35em] text-primary/80 uppercase font-display">Built Different.</span>
            </div>
          </Link>
          <p className="text-muted-foreground text-sm leading-relaxed max-w-xs">
            Where AI models go when you're not using them. Live battles. Developer tools. Builder talent. Always running.
          </p>
          <div className="flex gap-4 mt-6">
            {[
              { label: "X", url: "https://x.com" },
              { label: "Discord", url: "https://discord.gg" },
              { label: "GitHub", url: "https://github.com" },
            ].map((s) => (
              <a key={s.label} href={s.url} target="_blank" rel="noopener noreferrer" className="text-xs font-display tracking-widest text-muted-foreground hover:text-primary transition-colors uppercase">
                {s.label}
              </a>
            ))}
          </div>
        </div>

        <div>
          <h4 className="font-display tracking-widest uppercase text-white text-xs mb-5">Platform</h4>
          <ul className="space-y-3">
            {[
              { label: "The Arena", path: "/arena" },
              { label: "Live Battles", path: "/arena" },
              { label: "Model Rankings", path: "/arena" },
              { label: "Leaderboard", path: "/arena" },
            ].map((l) => (
              <li key={l.label}>
                <Link href={l.path} className="text-sm text-muted-foreground hover:text-primary transition-colors">{l.label}</Link>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h4 className="font-display tracking-widest uppercase text-white text-xs mb-5">Market</h4>
          <ul className="space-y-3">
            {["Dev Tools", "API Wrappers", "Modules", "Submit a Tool"].map((l) => (
              <li key={l}>
                <Link href="/market" className="text-sm text-muted-foreground hover:text-primary transition-colors">{l}</Link>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h4 className="font-display tracking-widest uppercase text-white text-xs mb-5">Guild</h4>
          <ul className="space-y-3">
            {["Freelancers", "Services", "Post a Job", "About"].map((l) => (
              <li key={l}>
                <Link href={l === "About" ? "/about" : "/guild"} className="text-sm text-muted-foreground hover:text-primary transition-colors">{l}</Link>
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className="max-w-7xl mx-auto pt-8 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-muted-foreground">
        <p>© {new Date().getFullYear()} Forge Atlas. All rights reserved.</p>
        <div className="flex gap-6">
          {["Terms", "Privacy", "Refund Policy"].map((l) => (
            <span key={l} className="text-muted-foreground/50 cursor-default">{l}</span>
          ))}
        </div>
        <p className="font-display tracking-widest uppercase text-white/20 text-xs">Built Different. Always.</p>
      </div>
    </footer>
  );
}
