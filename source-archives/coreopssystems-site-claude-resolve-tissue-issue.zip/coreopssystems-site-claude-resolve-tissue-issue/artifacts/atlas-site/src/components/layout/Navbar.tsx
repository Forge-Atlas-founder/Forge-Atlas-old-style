import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { AnimatePresence, motion } from "framer-motion";
import { AtlasIDButton } from "@/components/AtlasID";

const navLinks = [
  { name: "Home", path: "/" },
  { name: "Arena", path: "/arena" },
  { name: "Forum", path: "/forum" },
  { name: "Market", path: "/market" },
  { name: "Guild", path: "/guild" },
  { name: "About", path: "/about" },
];

export function Navbar() {
  const [location] = useLocation();
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    setMobileMenuOpen(false);
  }, [location]);

  useEffect(() => {
    document.body.style.overflow = mobileMenuOpen ? "hidden" : "";
    return () => { document.body.style.overflow = ""; };
  }, [mobileMenuOpen]);

  return (
    <>
      <nav className={cn(
        "fixed top-0 w-full z-40 transition-all duration-500 border-b",
        isScrolled
          ? "bg-background/90 backdrop-blur-xl border-white/5 py-3"
          : "bg-transparent border-transparent py-5"
      )}>
        <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
          <Link href="/" className="group flex items-center gap-2.5 z-50 relative">
            <svg viewBox="0 0 100 100" className="w-8 h-8 group-hover:scale-105 transition-transform duration-300">
              <rect width="100" height="100" fill="#0a0a0a"/>
              <path d="M50 12 L18 88 H34 L42 66 H58 L66 88 H82 L50 12 Z" fill="#D4A843"/>
              <path d="M45 52 H55 L50 38 Z" fill="#0a0a0a"/>
            </svg>
            <div className="flex flex-col leading-none">
              <span className="font-display text-xl font-bold tracking-[0.2em] text-white">FORGE ATLAS</span>
              <span className="text-[9px] tracking-[0.35em] text-primary/80 uppercase font-display">Built Different.</span>
            </div>
          </Link>

          <div className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                href={link.path}
                className={cn(
                  "text-xs font-display tracking-[0.2em] uppercase transition-colors hover:text-primary relative group pb-1",
                  location === link.path ? "text-primary" : "text-muted-foreground"
                )}
              >
                {link.name}
                <span className={cn(
                  "absolute bottom-0 left-0 w-full h-px bg-primary transform origin-left transition-transform duration-300",
                  location === link.path ? "scale-x-100" : "scale-x-0 group-hover:scale-x-100"
                )} />
              </Link>
            ))}
          </div>

          <div className="hidden md:flex items-center gap-3">
            <AtlasIDButton />
            <Link href="/arena">
              <Button size="sm">Enter Arena</Button>
            </Link>
          </div>

          <button
            className="md:hidden z-50 relative text-white p-1"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            aria-label="Toggle menu"
          >
            {mobileMenuOpen ? <X size={26} /> : <Menu size={26} />}
          </button>
        </div>
      </nav>

      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 z-30 bg-background flex flex-col items-center justify-center"
          >
            <div className="space-y-8 text-center">
              {navLinks.map((link, i) => (
                <motion.div
                  key={link.path}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.08 }}
                >
                  <Link
                    href={link.path}
                    className={cn(
                      "block text-4xl font-display font-bold tracking-widest uppercase transition-colors",
                      location === link.path ? "text-primary" : "text-white hover:text-primary"
                    )}
                  >
                    {link.name}
                  </Link>
                </motion.div>
              ))}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: navLinks.length * 0.08 }}
                className="pt-6"
              >
                <Link href="/arena">
                  <Button size="lg">Enter Arena</Button>
                </Link>
              </motion.div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
