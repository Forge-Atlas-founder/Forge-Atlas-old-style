import * as React from "react";
import { cn } from "@/lib/utils";

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "default" | "ghost" | "outline" | "secondary";
  size?: "default" | "sm" | "lg" | "icon";
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant = "default", size = "default", ...props }, ref) => {
    return (
      <button
        ref={ref}
        className={cn(
          "inline-flex items-center justify-center whitespace-nowrap text-sm font-display tracking-widest uppercase transition-all duration-300 disabled:pointer-events-none disabled:opacity-50",
          {
            "bg-primary text-primary-foreground hover:bg-primary/90 hover:shadow-[0_0_20px_rgba(245,200,66,0.3)] hover:-translate-y-0.5 active:translate-y-0":
              variant === "default",
            "border border-primary text-primary hover:bg-primary/10 hover:shadow-[0_0_15px_rgba(245,200,66,0.15)] hover:-translate-y-0.5 active:translate-y-0":
              variant === "outline",
            "bg-secondary text-secondary-foreground hover:bg-secondary/80":
              variant === "secondary",
            "hover:bg-white/5 hover:text-white": variant === "ghost",
            "h-10 px-6 py-2": size === "default",
            "h-9 px-4": size === "sm",
            "h-14 px-10 text-lg": size === "lg",
            "h-10 w-10": size === "icon",
          },
          className
        )}
        {...props}
      />
    );
  }
);
Button.displayName = "Button";

export { Button };
