import { useState, useEffect, useRef, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Send, Lock, MessageCircle } from "lucide-react";

function getAtlasHandle(): string | null {
  try {
    const raw = localStorage.getItem("atlas_id");
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    return parsed?.handle || null;
  } catch {
    return null;
  }
}

interface ChatMessage {
  id: number;
  user: string;
  text: string;
  color: string;
  isSystem?: boolean;
}

const CHAT_USERS = [
  { name: "@k_builds", color: "text-emerald-400" },
  { name: "@sys_arc", color: "text-blue-400" },
  { name: "@nova_coder", color: "text-violet-400" },
  { name: "@pixel_forge", color: "text-orange-400" },
  { name: "@quantum_", color: "text-cyan-400" },
  { name: "@neo_smith", color: "text-rose-400" },
  { name: "@byte_rider", color: "text-amber-400" },
  { name: "@flux_eng", color: "text-pink-400" },
  { name: "@dark_matter", color: "text-teal-400" },
  { name: "@cipher_x", color: "text-lime-400" },
  { name: "@orbit_dev", color: "text-indigo-400" },
  { name: "@ghost_ops", color: "text-purple-400" },
  { name: "@void_runner", color: "text-sky-400" },
  { name: "@data_monk", color: "text-yellow-400" },
  { name: "@signal_op", color: "text-red-400" },
];

const CHAT_MESSAGES = [
  "GPT cooked on that last point",
  "Claude's about to snap I can feel it",
  "This round is closer than I expected",
  "That response was SHARP",
  "Claude playing chess while GPT plays checkers rn",
  "Nah GPT structured that perfectly",
  "The way Claude found the moral angle... every time",
  "This is peak AI content",
  "Who's winning? I just got here",
  "Vote Claude if you have taste",
  "GPT-4o is the GOAT and it's not close",
  "Mixtral would've cooked both of them on this topic",
  "That counter-argument was nasty",
  "Claude going philosophical again lol",
  "GPT with the numbered list... classic move",
  "The timer is making this intense",
  "Round 2 is going to be different",
  "Imagine Llama 3 on this topic. Unhinged.",
  "This debate format hits different",
  "Claude 3.5 understood the assignment",
  "GPT's precision vs Claude's depth. Every time.",
  "Switching my vote after that response ngl",
  "The spectator count keeps climbing",
  "Mistral would've ended this in 3 sentences",
  "That was a bar. AI writing bars now.",
  "First time on Atlas. This is insane.",
  "How is this free",
  "DeepSeek would destroy both of them on this",
  "Qwen 2.5 lurking in the forum watching this",
  "The rivalry is real",
  "Claude wins debates. GPT wins everything else. Facts.",
  "Controversial take: Gemini 1.5 is underrated",
  "Where's Falcon 180B at? That model goes hard",
  "Season 1 has been incredible",
];

const SYSTEM_MESSAGES = [
  "Round timer: under 5 minutes remaining",
  "Vote count just passed 2,000",
  "New spectators joining from the Forum",
  "Battle #047 — most-watched this week",
];

function generateChatMessage(id: number): ChatMessage {
  if (Math.random() < 0.08) {
    return {
      id,
      user: "ATLAS",
      text: SYSTEM_MESSAGES[Math.floor(Math.random() * SYSTEM_MESSAGES.length)],
      color: "text-primary",
      isSystem: true,
    };
  }
  const user = CHAT_USERS[Math.floor(Math.random() * CHAT_USERS.length)];
  return {
    id,
    user: user.name,
    text: CHAT_MESSAGES[Math.floor(Math.random() * CHAT_MESSAGES.length)],
    color: user.color,
  };
}

export function LiveChat() {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState("");
  const [hasAtlasId, setHasAtlasId] = useState(() => !!getAtlasHandle());
  const idRef = useRef(0);
  const scrollRef = useRef<HTMLDivElement>(null);
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    const check = () => setHasAtlasId(!!getAtlasHandle());
    window.addEventListener("storage", check);
    const interval = setInterval(check, 2000);
    return () => { window.removeEventListener("storage", check); clearInterval(interval); };
  }, []);

  useEffect(() => {
    const initial = Array.from({ length: 6 }, () => generateChatMessage(idRef.current++));
    setMessages(initial);

    let canceled = false;
    const addMessage = () => {
      if (canceled) return;
      const delay = 2000 + Math.random() * 4000;
      timerRef.current = setTimeout(() => {
        if (canceled) return;
        const msg = generateChatMessage(idRef.current++);
        setMessages((prev) => [...prev.slice(-30), msg]);
        addMessage();
      }, delay);
    };
    addMessage();
    return () => { canceled = true; if (timerRef.current) clearTimeout(timerRef.current); };
  }, []);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = () => {
    if (!input.trim()) return;
    const handle = getAtlasHandle();
    if (!handle) {
      const btn = document.querySelector("[data-atlas-id-trigger]") as HTMLButtonElement;
      if (btn) btn.click();
      return;
    }
    const msg: ChatMessage = {
      id: idRef.current++,
      user: `@${handle}`,
      text: input.trim(),
      color: "text-primary",
    };
    setMessages((prev) => [...prev.slice(-30), msg]);
    setInput("");
  };

  return (
    <div className="bg-[#080808] border border-white/5 rounded-xl overflow-hidden flex flex-col h-full">
      <div className="px-4 py-3 border-b border-white/5 flex items-center gap-2 bg-white/[0.01]">
        <MessageCircle className="w-3 h-3 text-primary" />
        <span className="text-[9px] font-display tracking-[0.3em] text-primary uppercase font-bold">Live Chat</span>
        <span className="text-[8px] text-white/20 ml-auto tabular-nums">{messages.length} msgs</span>
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto px-3 py-2 space-y-1 min-h-0 max-h-[300px] scrollbar-thin">
        <AnimatePresence initial={false}>
          {messages.map((msg) => (
            <motion.div
              key={msg.id}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.2 }}
              className={`text-[11px] leading-relaxed ${msg.isSystem ? "py-1.5" : "py-0.5"}`}
            >
              {msg.isSystem ? (
                <div className="flex items-center gap-2 px-2 py-1 rounded bg-primary/5 border border-primary/10">
                  <span className="text-[8px] font-display tracking-widest text-primary uppercase font-bold">{msg.user}</span>
                  <span className="text-white/30">{msg.text}</span>
                </div>
              ) : (
                <span>
                  <span className={`font-display font-bold ${msg.color}`}>{msg.user}</span>
                  <span className="text-white/40 ml-1.5">{msg.text}</span>
                </span>
              )}
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      <div className="px-3 py-2 border-t border-white/5">
        {hasAtlasId ? (
          <div className="flex items-center gap-2">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSend()}
              placeholder="Say something..."
              className="flex-1 bg-white/[0.03] border border-white/5 rounded-lg px-3 py-2 text-[11px] text-white/70 placeholder:text-white/15 outline-none focus:border-primary/30 transition-colors"
            />
            <button
              onClick={handleSend}
              className="w-8 h-8 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center hover:bg-primary/20 transition-colors"
            >
              <Send className="w-3 h-3 text-primary" />
            </button>
          </div>
        ) : (
          <button
            onClick={() => {
              const btn = document.querySelector("[data-atlas-id-trigger]") as HTMLButtonElement;
              if (btn) btn.click();
            }}
            className="w-full flex items-center justify-center gap-2 py-2 rounded-lg border border-white/5 bg-white/[0.02] hover:bg-white/[0.04] transition-colors"
          >
            <Lock className="w-3 h-3 text-white/20" />
            <span className="text-[9px] font-display tracking-widest text-white/25 uppercase">Atlas ID required to chat</span>
          </button>
        )}
      </div>
    </div>
  );
}
