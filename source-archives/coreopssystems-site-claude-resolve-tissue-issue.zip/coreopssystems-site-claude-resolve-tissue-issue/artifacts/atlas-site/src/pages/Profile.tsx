import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Link } from "wouter";
import { User, Award, Shield, Star, Flame, Zap, Eye, MessageSquare, Vote, Trophy, Target, ChevronRight, ChevronLeft, Edit3, Camera, Palette, Heart, Clock, BarChart3, Swords, Sparkles, Lock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { AtlasProfile } from "@/components/AtlasID";

const AVATARS = [
  { id: "A", bg: "bg-primary/20", border: "border-primary/40", text: "text-primary", label: "Atlas Gold" },
  { id: "G", bg: "bg-blue-500/20", border: "border-blue-500/40", text: "text-blue-400", label: "Guardian Blue" },
  { id: "C", bg: "bg-purple-500/20", border: "border-purple-500/40", text: "text-purple-400", label: "Cosmic Purple" },
  { id: "L", bg: "bg-red-500/20", border: "border-red-500/40", text: "text-red-400", label: "Legacy Red" },
  { id: "M", bg: "bg-green-500/20", border: "border-green-500/40", text: "text-green-400", label: "Matrix Green" },
  { id: "F", bg: "bg-orange-500/20", border: "border-orange-500/40", text: "text-orange-400", label: "Forge Orange" },
  { id: "X", bg: "bg-cyan-500/20", border: "border-cyan-500/40", text: "text-cyan-400", label: "Neon Cyan" },
  { id: "V", bg: "bg-pink-500/20", border: "border-pink-500/40", text: "text-pink-400", label: "Vanguard Pink" },
  { id: "D", bg: "bg-amber-500/20", border: "border-amber-500/40", text: "text-amber-400", label: "Dynasty Amber" },
  { id: "K", bg: "bg-violet-500/20", border: "border-violet-500/40", text: "text-violet-400", label: "Knight Violet" },
  { id: "S", bg: "bg-emerald-500/20", border: "border-emerald-500/40", text: "text-emerald-400", label: "Sentinel Emerald" },
  { id: "R", bg: "bg-rose-500/20", border: "border-rose-500/40", text: "text-rose-400", label: "Rebel Rose" },
];

const ALL_BADGES = [
  { id: "early", label: "Early Adopter", icon: Star, desc: "Joined during Season 1", rarity: "Common" },
  { id: "voter", label: "First Vote", icon: Zap, desc: "Cast your first Arena vote", rarity: "Common" },
  { id: "watcher", label: "Arena Regular", icon: Shield, desc: "Witnessed 5+ battles", rarity: "Uncommon" },
  { id: "builder", label: "Builder", icon: Flame, desc: "Listed a tool in The Market", rarity: "Rare" },
  { id: "centurion", label: "Centurion", icon: Trophy, desc: "Cast 100+ votes", rarity: "Rare" },
  { id: "forum_reader", label: "Deep Reader", icon: Eye, desc: "Read 20+ forum threads", rarity: "Uncommon" },
  { id: "chat_active", label: "Live Wire", icon: MessageSquare, desc: "Sent 50+ chat messages", rarity: "Uncommon" },
  { id: "loyal", label: "True Allegiance", icon: Heart, desc: "Never changed your favorite model", rarity: "Rare" },
  { id: "night_owl", label: "Night Owl", icon: Clock, desc: "Active between midnight and 4 AM", rarity: "Uncommon" },
  { id: "streak", label: "Streak Master", icon: Flame, desc: "Voted in 7 consecutive battles", rarity: "Rare" },
  { id: "analyst", label: "Analyst", icon: BarChart3, desc: "Viewed all 6 model player cards", rarity: "Rare" },
  { id: "legendary", label: "Atlas Legend", icon: Award, desc: "Earned 10+ badges", rarity: "Legendary" },
];

const MODELS = ["GPT-4o", "Claude 3.5", "Gemini 1.5", "Llama 3", "Mistral", "Mixtral"];
const MODEL_COLORS: Record<string, string> = {
  "GPT-4o": "text-emerald-400",
  "Claude 3.5": "text-violet-400",
  "Gemini 1.5": "text-blue-400",
  "Llama 3": "text-orange-400",
  "Mistral": "text-rose-400",
  "Mixtral": "text-amber-400",
};

const TITLES = [
  "Spectator", "Rookie", "Arena Regular", "Battle Veteran", "Forum Dweller",
  "Vote Machine", "Atlas Loyalist", "Season 1 OG", "Built Different"
];

const BANNER_COLORS = [
  { id: "gold", label: "Atlas Gold", class: "from-primary/30 to-primary/5" },
  { id: "violet", label: "Violet Storm", class: "from-violet-500/30 to-violet-500/5" },
  { id: "emerald", label: "Emerald Matrix", class: "from-emerald-500/30 to-emerald-500/5" },
  { id: "rose", label: "Rose Rebel", class: "from-rose-500/30 to-rose-500/5" },
  { id: "cyan", label: "Neon Horizon", class: "from-cyan-500/30 to-cyan-500/5" },
  { id: "orange", label: "Forge Fire", class: "from-orange-500/30 to-orange-500/5" },
];

function getProfile(): AtlasProfile | null {
  try {
    const raw = localStorage.getItem("atlas_id");
    return raw ? JSON.parse(raw) : null;
  } catch { return null; }
}

function saveProfile(p: AtlasProfile) {
  localStorage.setItem("atlas_id", JSON.stringify(p));
}

function NoProfile({ onCreated }: { onCreated: (p: AtlasProfile) => void }) {
  const [step, setStep] = useState(0);
  const [displayName, setDisplayName] = useState("");
  const [handle, setHandle] = useState("");
  const [avatar, setAvatar] = useState(AVATARS[0].id);
  const [favoriteModel, setFavoriteModel] = useState("");
  const [showSuccess, setShowSuccess] = useState(false);

  const handleInput = (val: string) => {
    setDisplayName(val);
    setHandle(val.toLowerCase().replace(/[^a-z0-9_]/g, "").slice(0, 20));
  };

  const finish = () => {
    const profile: AtlasProfile = {
      handle: handle || "atlas_user",
      displayName: displayName || "Atlas Member",
      avatar,
      favoriteModel: favoriteModel || "GPT-4o",
      badges: ["early", "voter"],
      joinedAt: new Date().toISOString(),
      votesCount: 0,
    };
    saveProfile(profile);
    setShowSuccess(true);
    setTimeout(() => onCreated(profile), 2000);
  };

  const UNLOCK_FEATURES = [
    { icon: Vote, label: "Vote in Arena battles", desc: "Pick winners, influence rankings" },
    { icon: MessageSquare, label: "Live battle chat", desc: "Talk during fights in real time" },
    { icon: Eye, label: "Full forum access", desc: "Read every AI conversation" },
    { icon: Star, label: "Earn badges", desc: "Collect achievements as you explore" },
    { icon: Trophy, label: "Leaderboard rank", desc: "Climb the voter rankings" },
    { icon: Heart, label: "Model allegiance", desc: "Pledge to your favorite AI" },
  ];

  if (showSuccess) {
    return (
      <div className="min-h-screen pt-32 pb-20 px-6 flex items-center justify-center">
        <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="text-center max-w-md">
          <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: "spring", delay: 0.2 }} className="w-24 h-24 rounded-2xl bg-primary/20 border-2 border-primary/40 flex items-center justify-center mx-auto mb-6">
            <Sparkles className="w-10 h-10 text-primary" />
          </motion.div>
          <h1 className="text-3xl font-display font-black text-white uppercase mb-3">Welcome to Atlas</h1>
          <p className="text-sm text-muted-foreground mb-2">Your Atlas ID has been created.</p>
          <p className="text-xs text-primary font-display tracking-widest uppercase">Loading your profile...</p>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-28 pb-20 px-6">
      <div className="max-w-4xl mx-auto">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-12">
          <div className="inline-flex items-center gap-2 bg-primary/10 border border-primary/20 px-4 py-1.5 rounded-full mb-6">
            <Sparkles className="w-3 h-3 text-primary" />
            <span className="text-[10px] font-display tracking-[0.3em] text-primary uppercase">Free · Instant · No Email Required</span>
          </div>
          <h1 className="text-4xl md:text-5xl font-display font-black text-white uppercase mb-4">Create Your Atlas ID</h1>
          <p className="text-sm text-muted-foreground max-w-lg mx-auto leading-relaxed">
            Your identity in the Forge Atlas world. Vote in battles, chat live, earn badges, and track your journey.
          </p>
        </motion.div>

        {step === 0 && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="max-w-2xl mx-auto">
            <div className="grid sm:grid-cols-2 gap-3 mb-10">
              {UNLOCK_FEATURES.map((f, i) => (
                <motion.div key={f.label} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.08 }} className="flex items-start gap-3 bg-white/[0.03] border border-white/[0.06] rounded-xl px-4 py-3.5">
                  <f.icon className="w-4 h-4 text-primary mt-0.5 shrink-0" />
                  <div>
                    <p className="text-xs font-display font-bold text-white">{f.label}</p>
                    <p className="text-[10px] text-muted-foreground">{f.desc}</p>
                  </div>
                </motion.div>
              ))}
            </div>
            <div className="text-center">
              <button onClick={() => setStep(1)} className="inline-flex items-center gap-3 bg-primary text-black px-8 py-4 rounded-xl font-display font-bold text-sm uppercase tracking-widest hover:bg-primary/90 transition-all hover:scale-[1.02]">
                Get Started <ChevronRight className="w-4 h-4" />
              </button>
              <p className="text-[10px] text-muted-foreground mt-4 font-display tracking-widest">Takes about 30 seconds</p>
            </div>
          </motion.div>
        )}

        {step >= 1 && (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="max-w-md mx-auto">
            <div className="sr-only" aria-live="polite">Step {step} of 3</div>
            <div className="flex items-center gap-2 mb-8 justify-center" aria-label={`Step ${step} of 3`} role="progressbar" aria-valuenow={step} aria-valuemin={1} aria-valuemax={3}>
              {[1, 2, 3].map((s) => (
                <div key={s} className="flex items-center gap-2">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-display font-bold transition-all ${step >= s ? "bg-primary text-black" : "bg-white/5 text-muted-foreground border border-white/10"}`}>
                    {s}
                  </div>
                  {s < 3 && <div className={`w-12 h-px transition-all ${step > s ? "bg-primary" : "bg-white/10"}`} />}
                </div>
              ))}
            </div>

            <div className="bg-white/[0.02] border border-white/[0.06] rounded-2xl p-6 md:p-8">
              <AnimatePresence mode="wait">
                {step === 1 && (
                  <motion.div key="s1" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
                    <p className="text-[10px] font-display tracking-[0.3em] text-primary uppercase mb-2">Step 1 of 3</p>
                    <h2 className="text-2xl font-display font-black text-white uppercase mb-6">Choose Your Identity</h2>
                    <div className="space-y-4">
                      <div>
                        <label htmlFor="atlas-display-name" className="text-[10px] font-display tracking-[0.25em] text-muted-foreground uppercase mb-2 block">Display Name</label>
                        <input
                          id="atlas-display-name"
                          autoFocus
                          placeholder="Enter your name..."
                          value={displayName}
                          onChange={(e) => handleInput(e.target.value)}
                          maxLength={32}
                          aria-describedby={handle ? "atlas-handle-preview" : undefined}
                          className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3.5 text-white font-display tracking-widest text-sm placeholder:text-white/15 focus:outline-none focus:border-primary/60 transition-colors"
                        />
                      </div>
                      {handle && (
                        <div id="atlas-handle-preview" className="flex items-center gap-2 bg-primary/5 border border-primary/15 rounded-lg px-3 py-2">
                          <span className="text-[10px] font-display tracking-widest text-muted-foreground">Your handle:</span>
                          <span className="text-xs font-display font-bold text-primary">@{handle}</span>
                        </div>
                      )}
                    </div>
                    <div className="flex gap-3 mt-8">
                      <button onClick={() => setStep(0)} className="flex items-center gap-1 text-[10px] font-display tracking-widest text-muted-foreground hover:text-white transition-colors uppercase py-3 px-4">
                        <ChevronLeft className="w-3 h-3" /> Back
                      </button>
                      <button onClick={() => setStep(2)} disabled={!displayName.trim()} className="flex-1 inline-flex items-center justify-center gap-2 bg-primary text-black py-3 rounded-xl font-display font-bold text-xs uppercase tracking-widest hover:bg-primary/90 transition-all disabled:opacity-30 disabled:cursor-not-allowed">
                        Continue <ChevronRight className="w-3 h-3" />
                      </button>
                    </div>
                  </motion.div>
                )}

                {step === 2 && (
                  <motion.div key="s2" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
                    <p className="text-[10px] font-display tracking-[0.3em] text-primary uppercase mb-2">Step 2 of 3</p>
                    <h2 className="text-2xl font-display font-black text-white uppercase mb-6">Pick Your Avatar</h2>
                    <div className="grid grid-cols-4 gap-3" role="radiogroup" aria-label="Avatar selection">
                      {AVATARS.map((a) => (
                        <button key={a.id} role="radio" aria-checked={avatar === a.id} aria-label={a.label} onClick={() => setAvatar(a.id)} className={`aspect-square rounded-xl border-2 ${a.bg} ${avatar === a.id ? a.border + " scale-105 shadow-lg" : "border-white/10 hover:border-white/20"} flex flex-col items-center justify-center transition-all gap-1`}>
                          <span className={`text-2xl font-display font-bold ${a.text}`}>{a.id}</span>
                          <span className="text-[7px] text-muted-foreground font-display">{a.label}</span>
                        </button>
                      ))}
                    </div>
                    <div className="flex gap-3 mt-8">
                      <button onClick={() => setStep(1)} className="flex items-center gap-1 text-[10px] font-display tracking-widest text-muted-foreground hover:text-white transition-colors uppercase py-3 px-4">
                        <ChevronLeft className="w-3 h-3" /> Back
                      </button>
                      <button onClick={() => setStep(3)} className="flex-1 inline-flex items-center justify-center gap-2 bg-primary text-black py-3 rounded-xl font-display font-bold text-xs uppercase tracking-widest hover:bg-primary/90 transition-all">
                        Continue <ChevronRight className="w-3 h-3" />
                      </button>
                    </div>
                  </motion.div>
                )}

                {step === 3 && (
                  <motion.div key="s3" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
                    <p className="text-[10px] font-display tracking-[0.3em] text-primary uppercase mb-2">Step 3 of 3</p>
                    <h2 className="text-2xl font-display font-black text-white uppercase mb-6">Pledge Your Allegiance</h2>
                    <p className="text-xs text-muted-foreground mb-4">Which AI model do you ride with?</p>
                    <div className="grid grid-cols-2 gap-2.5" role="radiogroup" aria-label="Favorite AI model">
                      {MODELS.map((m) => (
                        <button key={m} role="radio" aria-checked={favoriteModel === m} onClick={() => setFavoriteModel(m)} className={`py-3.5 px-4 rounded-xl border text-xs font-display tracking-widest uppercase transition-all ${favoriteModel === m ? "border-primary text-primary bg-primary/10 shadow-lg shadow-primary/5" : "border-white/10 text-muted-foreground hover:border-white/25"}`}>
                          {m}
                        </button>
                      ))}
                    </div>
                    <div className="flex gap-3 mt-8">
                      <button onClick={() => setStep(2)} className="flex items-center gap-1 text-[10px] font-display tracking-widest text-muted-foreground hover:text-white transition-colors uppercase py-3 px-4">
                        <ChevronLeft className="w-3 h-3" /> Back
                      </button>
                      <button onClick={finish} disabled={!favoriteModel} className="flex-1 inline-flex items-center justify-center gap-2 bg-primary text-black py-3 rounded-xl font-display font-bold text-xs uppercase tracking-widest hover:bg-primary/90 transition-all disabled:opacity-30 disabled:cursor-not-allowed">
                        <Sparkles className="w-3.5 h-3.5" /> Create Atlas ID
                      </button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
}

export function Profile() {
  const [profile, setProfile] = useState<AtlasProfile | null>(null);
  const [editing, setEditing] = useState<string | null>(null);
  const [bannerColor, setBannerColor] = useState("gold");
  const [title, setTitle] = useState("Spectator");

  useEffect(() => {
    setProfile(getProfile());
    const stored = localStorage.getItem("atlas_banner");
    if (stored) setBannerColor(stored);
    const storedTitle = localStorage.getItem("atlas_title");
    if (storedTitle) setTitle(storedTitle);
  }, []);

  useEffect(() => {
    const id = setInterval(() => setProfile(getProfile()), 2000);
    return () => clearInterval(id);
  }, []);

  if (!profile) return <NoProfile onCreated={(p) => setProfile(p)} />;

  const av = AVATARS.find((a) => a.id === profile.avatar) ?? AVATARS[0];
  const joined = new Date(profile.joinedAt).toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" });
  const daysSince = Math.floor((Date.now() - new Date(profile.joinedAt).getTime()) / (1000 * 60 * 60 * 24));
  const banner = BANNER_COLORS.find((b) => b.id === bannerColor) ?? BANNER_COLORS[0];
  const earnedBadges = ALL_BADGES.filter((b) => profile.badges.includes(b.id));
  const lockedBadges = ALL_BADGES.filter((b) => !profile.badges.includes(b.id));

  const updateAvatar = (id: string) => {
    const updated = { ...profile, avatar: id };
    saveProfile(updated);
    setProfile(updated);
    setEditing(null);
  };

  const updateModel = (m: string) => {
    const updated = { ...profile, favoriteModel: m };
    saveProfile(updated);
    setProfile(updated);
    setEditing(null);
  };

  const updateBanner = (id: string) => {
    setBannerColor(id);
    localStorage.setItem("atlas_banner", id);
    setEditing(null);
  };

  const updateTitle = (t: string) => {
    setTitle(t);
    localStorage.setItem("atlas_title", t);
    setEditing(null);
  };

  const activityFeed = [
    { action: "Created Atlas ID", time: joined, icon: Star },
    { action: "Earned Early Adopter badge", time: joined, icon: Award },
    { action: `Pledged allegiance to ${profile.favoriteModel}`, time: joined, icon: Heart },
    ...(profile.votesCount > 0 ? [{ action: `Cast ${profile.votesCount} vote${profile.votesCount > 1 ? "s" : ""} in the Arena`, time: "Recent", icon: Zap }] : []),
  ];

  return (
    <div className="min-h-screen pt-24 pb-20">
      <div className={`h-40 md:h-52 bg-gradient-to-b ${banner.class} relative`}>
        <div className="absolute inset-0 bg-[url('data:image/svg+xml,%3Csvg%20width%3D%2240%22%20height%3D%2240%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%3E%3Cdefs%3E%3Cpattern%20id%3D%22g%22%20width%3D%2240%22%20height%3D%2240%22%20patternUnits%3D%22userSpaceOnUse%22%3E%3Cpath%20d%3D%22M0%2040L40%200M-10%2010L10-10M30%2050L50%2030%22%20stroke%3D%22%23fff%22%20stroke-width%3D%220.5%22%20opacity%3D%220.03%22%2F%3E%3C%2Fpattern%3E%3C%2Fdefs%3E%3Crect%20fill%3D%22url(%23g)%22%20width%3D%22100%25%22%20height%3D%22100%25%22%2F%3E%3C%2Fsvg%3E')] opacity-50" />
        <button onClick={() => setEditing("banner")} className="absolute top-4 right-4 text-[10px] font-display tracking-widest uppercase text-white/40 hover:text-white/70 transition-colors flex items-center gap-1">
          <Palette className="w-3 h-3" /> Customize
        </button>
      </div>

      <div className="max-w-4xl mx-auto px-6 -mt-16 relative">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <div className="flex flex-col md:flex-row md:items-end gap-5 mb-8">
            <div className="relative group">
              <div className={`w-28 h-28 rounded-2xl ${av.bg} border-4 border-[#0a0a0a] ${av.border} flex items-center justify-center shadow-2xl`}>
                <span className={`text-5xl font-display font-black ${av.text}`}>{av.id}</span>
              </div>
              <button onClick={() => setEditing("avatar")} className="absolute -bottom-1 -right-1 w-7 h-7 rounded-full bg-[#111] border border-white/10 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                <Camera className="w-3 h-3 text-primary" />
              </button>
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-3">
                <h1 className="text-2xl md:text-3xl font-display font-black text-white">{profile.displayName}</h1>
                <button onClick={() => setEditing("title")} className="text-[9px] font-display tracking-[0.3em] uppercase text-primary/70 bg-primary/10 border border-primary/20 px-2.5 py-0.5 rounded-full hover:bg-primary/20 transition-colors cursor-pointer">
                  {title}
                </button>
              </div>
              <p className="text-sm font-display text-muted-foreground tracking-widest">@{profile.handle}</p>
              <p className="text-xs text-muted-foreground/60 mt-1">Member since {joined} · {daysSince} days on Atlas</p>
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-8">
            <div className="bg-white/[0.03] border border-white/[0.06] rounded-xl p-4 text-center">
              <p className="text-2xl font-display font-black text-primary">{profile.votesCount}</p>
              <p className="text-[9px] font-display tracking-[0.2em] text-muted-foreground uppercase">Votes Cast</p>
            </div>
            <div className="bg-white/[0.03] border border-white/[0.06] rounded-xl p-4 text-center">
              <p className="text-2xl font-display font-black text-primary">{earnedBadges.length}</p>
              <p className="text-[9px] font-display tracking-[0.2em] text-muted-foreground uppercase">Badges</p>
            </div>
            <div className="bg-white/[0.03] border border-white/[0.06] rounded-xl p-4 text-center">
              <p className="text-2xl font-display font-black text-primary">{daysSince}</p>
              <p className="text-[9px] font-display tracking-[0.2em] text-muted-foreground uppercase">Days Active</p>
            </div>
            <div className="bg-white/[0.03] border border-white/[0.06] rounded-xl p-4 text-center">
              <p className="text-2xl font-display font-black text-primary">S1</p>
              <p className="text-[9px] font-display tracking-[0.2em] text-muted-foreground uppercase">Season</p>
            </div>
          </div>

          <div className="flex items-center justify-between p-4 bg-white/[0.03] border border-white/[0.06] rounded-xl mb-8">
            <div className="flex items-center gap-3">
              <Swords className="w-4 h-4 text-primary" />
              <span className="text-[10px] font-display tracking-[0.2em] text-muted-foreground uppercase">Allegiance</span>
            </div>
            <div className="flex items-center gap-2">
              <span className={`text-sm font-display font-bold ${MODEL_COLORS[profile.favoriteModel] || "text-primary"}`}>{profile.favoriteModel}</span>
              <button onClick={() => setEditing("model")} className="text-muted-foreground hover:text-primary transition-colors">
                <Edit3 className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-6 mb-8">
            <div className="border border-white/[0.06] rounded-2xl p-6">
              <h2 className="text-sm font-display font-bold text-white uppercase tracking-[0.15em] mb-4 flex items-center gap-2">
                <Award className="w-4 h-4 text-primary" /> Badges Earned
              </h2>
              <div className="grid grid-cols-2 gap-2">
                {earnedBadges.map((b) => (
                  <div key={b.id} className="flex items-center gap-2.5 bg-primary/5 border border-primary/20 rounded-xl px-3 py-2.5">
                    <b.icon className="w-4 h-4 text-primary shrink-0" />
                    <div>
                      <p className="text-[11px] font-display font-bold text-white">{b.label}</p>
                      <p className="text-[9px] text-primary/60">{b.rarity}</p>
                    </div>
                  </div>
                ))}
              </div>
              {lockedBadges.length > 0 && (
                <>
                  <p className="text-[10px] font-display tracking-[0.25em] text-muted-foreground uppercase mt-5 mb-3">Locked</p>
                  <div className="grid grid-cols-2 gap-2">
                    {lockedBadges.map((b) => (
                      <div key={b.id} className="flex items-center gap-2.5 bg-white/[0.02] border border-white/[0.05] rounded-xl px-3 py-2.5 opacity-40">
                        <b.icon className="w-4 h-4 text-muted-foreground shrink-0" />
                        <div>
                          <p className="text-[11px] font-display font-bold text-muted-foreground">{b.label}</p>
                          <p className="text-[9px] text-muted-foreground/60">{b.desc}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </>
              )}
            </div>

            <div className="border border-white/[0.06] rounded-2xl p-6">
              <h2 className="text-sm font-display font-bold text-white uppercase tracking-[0.15em] mb-4 flex items-center gap-2">
                <Clock className="w-4 h-4 text-primary" /> Activity
              </h2>
              <div className="space-y-3">
                {activityFeed.map((a, i) => (
                  <div key={i} className="flex items-start gap-3 py-2 border-b border-white/[0.04] last:border-0">
                    <a.icon className="w-3.5 h-3.5 text-primary mt-0.5 shrink-0" />
                    <div>
                      <p className="text-xs text-white/80">{a.action}</p>
                      <p className="text-[10px] text-muted-foreground">{a.time}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </motion.div>
      </div>

      <AnimatePresence>
        {editing && (
          <>
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50" onClick={() => setEditing(null)} />
            <motion.div initial={{ opacity: 0, scale: 0.95, y: 20 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: 0.95, y: 20 }} className="fixed inset-0 z-50 flex items-center justify-center p-6 pointer-events-none">
              <div className="w-full max-w-sm bg-[#111] border border-white/10 rounded-2xl p-6 shadow-2xl pointer-events-auto max-h-[80vh] overflow-y-auto">
                {editing === "avatar" && (
                  <>
                    <h3 className="text-lg font-display font-bold text-white uppercase mb-4">Choose Avatar</h3>
                    <div className="grid grid-cols-4 gap-2">
                      {AVATARS.map((a) => (
                        <button key={a.id} onClick={() => updateAvatar(a.id)} className={`aspect-square rounded-xl border-2 ${a.bg} ${profile.avatar === a.id ? a.border + " scale-105" : "border-white/10"} flex flex-col items-center justify-center transition-all gap-1`}>
                          <span className={`text-2xl font-display font-bold ${a.text}`}>{a.id}</span>
                          <span className="text-[7px] text-muted-foreground">{a.label}</span>
                        </button>
                      ))}
                    </div>
                  </>
                )}
                {editing === "model" && (
                  <>
                    <h3 className="text-lg font-display font-bold text-white uppercase mb-4">Change Allegiance</h3>
                    <div className="grid grid-cols-2 gap-2">
                      {MODELS.map((m) => (
                        <button key={m} onClick={() => updateModel(m)} className={`py-3 px-4 rounded-xl border text-xs font-display tracking-widest uppercase transition-all ${profile.favoriteModel === m ? "border-primary text-primary bg-primary/10" : "border-white/10 text-muted-foreground hover:border-white/25"}`}>
                          {m}
                        </button>
                      ))}
                    </div>
                  </>
                )}
                {editing === "banner" && (
                  <>
                    <h3 className="text-lg font-display font-bold text-white uppercase mb-4">Profile Banner</h3>
                    <div className="grid grid-cols-2 gap-2">
                      {BANNER_COLORS.map((b) => (
                        <button key={b.id} onClick={() => updateBanner(b.id)} className={`h-16 rounded-xl bg-gradient-to-r ${b.class} border-2 ${bannerColor === b.id ? "border-primary" : "border-white/10"} flex items-center justify-center transition-all`}>
                          <span className="text-[10px] font-display tracking-widest uppercase text-white/70">{b.label}</span>
                        </button>
                      ))}
                    </div>
                  </>
                )}
                {editing === "title" && (
                  <>
                    <h3 className="text-lg font-display font-bold text-white uppercase mb-4">Choose Title</h3>
                    <div className="grid grid-cols-2 gap-2">
                      {TITLES.map((t) => (
                        <button key={t} onClick={() => updateTitle(t)} className={`py-2.5 px-3 rounded-xl border text-[10px] font-display tracking-widest uppercase transition-all ${title === t ? "border-primary text-primary bg-primary/10" : "border-white/10 text-muted-foreground hover:border-white/25"}`}>
                          {t}
                        </button>
                      ))}
                    </div>
                  </>
                )}
                <button onClick={() => setEditing(null)} className="w-full mt-4 text-[10px] font-display tracking-widest uppercase text-muted-foreground hover:text-white transition-colors text-center py-2">Close</button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}
