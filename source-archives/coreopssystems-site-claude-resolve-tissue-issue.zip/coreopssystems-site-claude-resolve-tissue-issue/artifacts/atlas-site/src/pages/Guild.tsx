import { motion } from "framer-motion";
import { Users, Code, Palette, Brain, ArrowRight, CheckCircle, Star, Shield, Briefcase } from "lucide-react";
import { Button } from "@/components/ui/button";

const SERVICES = [
  {
    icon: Brain,
    title: "AI Integration",
    desc: "Connect your product to GPT, Claude, Gemini, or any model. API setup, prompt engineering, streaming, fine-tuning, and production deployment.",
    from: "$500",
    projects: 47,
  },
  {
    icon: Code,
    title: "Full-Stack Development",
    desc: "React, Next.js, Node, Python — end-to-end builds from spec to deployment. No juniors. No handoffs. One person, start to finish.",
    from: "$1,200",
    projects: 89,
  },
  {
    icon: Palette,
    title: "UI/UX Design",
    desc: "Interfaces that look intentional. Product design, design systems, and responsive builds from someone who understands both code and composition.",
    from: "$800",
    projects: 34,
  },
  {
    icon: Shield,
    title: "API & Infrastructure",
    desc: "REST and GraphQL APIs, database architecture, auth systems, Cloudflare Workers, and serverless infrastructure that scales without drama.",
    from: "$700",
    projects: 56,
  },
];

const FREELANCERS = [
  {
    handle: "@k_builds",
    role: "AI Integration Specialist",
    skills: ["GPT-4", "Claude API", "Cloudflare Workers", "Node.js"],
    rating: 5.0,
    projects: 23,
    available: true,
    bio: "Shipped 23 AI integrations. Zero downtime. Zero refunds.",
  },
  {
    handle: "@mdev_",
    role: "Full-Stack Engineer",
    skills: ["React", "Next.js", "PostgreSQL", "Stripe"],
    rating: 4.9,
    projects: 41,
    available: false,
    bio: "Currently on a 6-month contract. Returns in Q2.",
  },
  {
    handle: "@atlas_ux",
    role: "UI/UX Designer",
    skills: ["Figma", "Framer", "Design Systems", "Motion"],
    rating: 4.8,
    projects: 17,
    available: true,
    bio: "Design systems and product design. No templates.",
  },
  {
    handle: "@sys_arc",
    role: "Backend Architect",
    skills: ["Go", "PostgreSQL", "Redis", "AWS"],
    rating: 4.9,
    projects: 31,
    available: true,
    bio: "Infra that doesn't break at 3am. 99.99% uptime across clients.",
  },
];

const PROCESS = [
  { step: "01", title: "Submit", desc: "Describe your project, timeline, and budget. Takes 2 minutes." },
  { step: "02", title: "Match", desc: "We pair you with the right builder within 24 hours. No algorithms — manual selection." },
  { step: "03", title: "Build", desc: "Direct communication, milestone-based delivery, and code you own from day one." },
];

export function Guild() {
  return (
    <div className="w-full pt-20">

      <section className="py-24 px-6 border-b border-white/5 relative overflow-hidden">
        <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-primary/4 rounded-full blur-[160px] pointer-events-none" />
        <div className="max-w-4xl mx-auto text-center relative z-10">
          <motion.div
            initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}
            className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-white/10 bg-white/5 mb-8"
          >
            <Users className="w-3 h-3 text-muted-foreground" />
            <span className="text-xs font-display tracking-[0.2em] text-muted-foreground uppercase">Coming Soon · Applications Open</span>
          </motion.div>
          <motion.h1
            initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
            className="text-5xl md:text-7xl font-display font-bold uppercase text-white leading-tight mb-4"
          >
            The Guild
          </motion.h1>
          <motion.p
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.2 }}
            className="text-lg text-muted-foreground max-w-2xl mx-auto mb-4"
          >
            A closed network of developers, designers, and AI specialists who operate at a different standard. We don't take everyone. We take the ones who ship.
          </motion.p>
          <motion.p
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.25 }}
            className="text-sm text-white/30 max-w-lg mx-auto mb-10"
          >
            Every member has been vetted, interviewed, and tested on real projects before joining.
          </motion.p>
          <motion.div
            initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}
            className="flex flex-col sm:flex-row gap-4 justify-center"
          >
            <Button size="lg">Hire from the Guild</Button>
            <Button size="lg" variant="outline">Apply to Join</Button>
          </motion.div>
        </div>
      </section>

      <section className="py-20 border-b border-white/5 px-6">
        <div className="max-w-5xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-8 md:divide-x divide-white/5">
          {[
            { value: "12", label: "Active Members" },
            { value: "226", label: "Projects Shipped" },
            { value: "4.9", label: "Avg Rating" },
            { value: "<24h", label: "Response Time" },
          ].map((stat, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 16 }} whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }} transition={{ delay: i * 0.08 }}
              className="text-center"
            >
              <div className="text-3xl md:text-4xl font-display font-bold text-primary mb-1">{stat.value}</div>
              <div className="text-xs font-display tracking-[0.25em] text-muted-foreground uppercase">{stat.label}</div>
            </motion.div>
          ))}
        </div>
      </section>

      <section className="py-24 px-6 border-b border-white/5">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <p className="text-primary font-display tracking-[0.3em] text-xs uppercase mb-3">What We Build</p>
            <h2 className="text-3xl md:text-4xl font-display font-bold text-white uppercase">Services</h2>
          </div>

          <div className="grid md:grid-cols-2 gap-5">
            {SERVICES.map((s, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.08 }}
                className="bg-card border border-white/5 rounded-2xl p-8 hover:border-primary/20 transition-all duration-300 group flex gap-6"
              >
                <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center shrink-0 group-hover:bg-primary/20 transition-colors">
                  <s.icon className="w-6 h-6 text-primary" />
                </div>
                <div className="flex-1">
                  <div className="flex items-start justify-between mb-2">
                    <h3 className="text-lg font-display font-bold text-white uppercase">{s.title}</h3>
                    <span className="text-sm text-muted-foreground font-display">from <span className="text-primary font-bold">{s.from}</span></span>
                  </div>
                  <p className="text-muted-foreground text-sm leading-relaxed mb-3">{s.desc}</p>
                  <p className="text-[10px] font-display tracking-widest text-white/25 uppercase">{s.projects} projects completed</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-24 px-6 border-b border-white/5">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-16">
            <p className="text-primary font-display tracking-[0.3em] text-xs uppercase mb-3">How It Works</p>
            <h2 className="text-3xl md:text-4xl font-display font-bold text-white uppercase">Three Steps</h2>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {PROCESS.map((p, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="text-center"
              >
                <div className="text-5xl font-display font-bold text-primary/15 mb-4">{p.step}</div>
                <h3 className="text-lg font-display font-bold text-white uppercase mb-3">{p.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{p.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-24 bg-[#0d0d0d] px-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row items-start md:items-end justify-between mb-12 gap-4">
            <div>
              <p className="text-primary font-display tracking-[0.3em] text-xs uppercase mb-2">The Roster</p>
              <h2 className="text-3xl font-display font-bold text-white uppercase">Featured Members</h2>
            </div>
            <Button variant="outline" size="sm">Browse All <Briefcase className="ml-2 w-3.5 h-3.5" /></Button>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-5">
            {FREELANCERS.map((f, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.08 }}
                className="bg-card border border-white/5 rounded-2xl p-6 hover:border-primary/20 transition-all duration-300 flex flex-col"
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center">
                    <span className="text-primary font-display font-bold">{f.handle[1].toUpperCase()}</span>
                  </div>
                  <span className={`text-[10px] font-display tracking-widest px-2.5 py-1 rounded-full uppercase border ${f.available ? "border-primary/40 text-primary bg-primary/10" : "border-white/10 text-white/30"}`}>
                    {f.available ? "Available" : "Booked"}
                  </span>
                </div>

                <p className="font-display font-bold text-white text-sm mb-0.5">{f.handle}</p>
                <p className="text-[10px] text-muted-foreground mb-3 uppercase tracking-wide font-display">{f.role}</p>
                <p className="text-xs text-white/40 leading-relaxed mb-4 flex-1">{f.bio}</p>

                <div className="flex flex-wrap gap-1.5 mb-5">
                  {f.skills.map((sk) => (
                    <span key={sk} className="text-[10px] font-display tracking-widest text-white/40 bg-white/5 px-2 py-1 rounded uppercase">{sk}</span>
                  ))}
                </div>

                <div className="flex items-center justify-between pt-4 border-t border-white/5">
                  <div className="flex items-center gap-1">
                    <Star className="w-3 h-3 text-primary fill-primary" />
                    <span className="text-sm font-bold text-white">{f.rating}</span>
                    <span className="text-[10px] text-muted-foreground">· {f.projects} projects</span>
                  </div>
                  <button className="text-[10px] font-display tracking-widest text-primary uppercase hover:underline">View</button>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-24 px-6">
        <div className="max-w-3xl mx-auto">
          <div className="bg-card border border-white/5 rounded-2xl p-10 md:p-16 text-center relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-transparent pointer-events-none" />
            <div className="relative z-10">
              <h2 className="text-3xl md:text-4xl font-display font-bold text-white uppercase mb-4">
                Think You Belong Here?
              </h2>
              <p className="text-muted-foreground mb-8 max-w-md mx-auto">
                The roster is tight by design. If you ship clean work and don't cut corners, we want to hear from you.
              </p>
              <div className="space-y-3 mb-10 text-left max-w-xs mx-auto">
                {[
                  "Portfolio review within 48 hours",
                  "No commission on your first project",
                  "Access to the Atlas client network",
                  "Direct payment — no middleman fees",
                ].map((item) => (
                  <div key={item} className="flex items-center gap-3">
                    <CheckCircle className="w-4 h-4 text-primary shrink-0" />
                    <span className="text-sm text-white/70">{item}</span>
                  </div>
                ))}
              </div>
              <Button size="lg">Apply Now <ArrowRight className="ml-2 w-5 h-5" /></Button>
            </div>
          </div>
        </div>
      </section>

    </div>
  );
}
