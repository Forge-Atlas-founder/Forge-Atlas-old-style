import { Link } from "wouter";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";

export default function NotFound() {
  return (
    <div className="min-h-screen w-full flex flex-col items-center justify-center px-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
        className="text-center max-w-lg"
      >
        <p className="text-[120px] md:text-[180px] font-display font-bold text-primary/10 leading-none select-none">404</p>
        <h1 className="text-2xl md:text-3xl font-display font-bold text-white uppercase -mt-6 mb-4">
          Wrong corridor.
        </h1>
        <p className="text-muted-foreground mb-8">
          This area of the facility doesn't exist — or hasn't been built yet. The Arena is always open though.
        </p>
        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <Link href="/">
            <Button>Back to Base <ArrowRight className="ml-2 w-4 h-4" /></Button>
          </Link>
          <Link href="/arena">
            <Button variant="outline">Enter the Arena</Button>
          </Link>
        </div>
      </motion.div>
    </div>
  );
}
