import { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Shield, BarChart3, Swords, Users, Vote, Zap, Trash2, Edit3, Play, Plus,
  RefreshCw, Clock, TrendingUp, AlertTriangle, CheckCircle, Eye, ChevronDown,
  ChevronRight, X, Save, Activity
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  setAdminKey, getAdminKey,
  getDashboard, getAdminBattles, updateBattle, deleteBattle,
  triggerBattle, seedBattle, getAdminVotes, deleteVote,
  getAdminProfiles, deleteProfile, getActivity,
  type DashboardData, type AdminBattle, type AdminVote, type AdminProfile, type ActivityData
} from "@/lib/adminApi";

function AdminLogin({ onLogin }: { onLogin: () => void }) {
  const [key, setKey] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    setAdminKey(key);
    try {
      await getDashboard();
      localStorage.setItem("admin_key", key);
      onLogin();
    } catch {
      setError("Invalid admin key");
      setAdminKey("");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-sm"
      >
        <div className="bg-[#0a0a0a] border border-white/10 rounded-2xl p-8">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 rounded-xl bg-primary/10 border border-primary/30 flex items-center justify-center">
              <Shield className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h1 className="text-lg font-display font-bold text-white">Atlas Admin</h1>
              <p className="text-[10px] font-display tracking-widest text-white/30 uppercase">Control Center</p>
            </div>
          </div>
          <form onSubmit={handleSubmit}>
            <input
              type="password"
              value={key}
              onChange={(e) => setKey(e.target.value)}
              placeholder="Enter admin key"
              className="w-full bg-black/50 border border-white/10 rounded-lg px-4 py-3 text-sm text-white placeholder:text-white/20 focus:outline-none focus:border-primary/50 mb-3 font-mono"
            />
            {error && <p className="text-red-400 text-xs mb-3">{error}</p>}
            <Button type="submit" className="w-full" disabled={loading || !key}>
              {loading ? "Verifying..." : "Access Dashboard"}
            </Button>
          </form>
        </div>
      </motion.div>
    </div>
  );
}

function StatCard({ label, value, sub, icon: Icon, color = "text-primary" }: {
  label: string; value: string | number; sub?: string;
  icon: React.ElementType; color?: string;
}) {
  return (
    <div className="bg-[#0a0a0a] border border-white/5 rounded-xl p-4">
      <div className="flex items-center justify-between mb-2">
        <span className="text-[9px] font-display tracking-widest text-white/30 uppercase">{label}</span>
        <Icon className={`w-3.5 h-3.5 ${color}`} />
      </div>
      <p className={`text-2xl font-display font-bold ${color}`}>{value}</p>
      {sub && <p className="text-[10px] text-white/20 mt-1">{sub}</p>}
    </div>
  );
}

function StatusBadge({ status }: { status: string }) {
  const colors: Record<string, string> = {
    live: "bg-red-500/20 text-red-400 border-red-500/30",
    generating: "bg-amber-500/20 text-amber-400 border-amber-500/30",
    scheduled: "bg-blue-500/20 text-blue-400 border-blue-500/30",
    complete: "bg-emerald-500/20 text-emerald-400 border-emerald-500/30",
  };
  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[9px] font-display tracking-widest uppercase border ${colors[status] ?? "bg-white/5 text-white/40 border-white/10"}`}>
      {status === "live" && <span className="w-1.5 h-1.5 rounded-full bg-red-400 mr-1.5 animate-pulse" />}
      {status}
    </span>
  );
}

function BattleRow({ battle, onRefresh }: { battle: AdminBattle; onRefresh: () => void }) {
  const [expanded, setExpanded] = useState(false);
  const [editing, setEditing] = useState(false);
  const [editData, setEditData] = useState({ status: battle.status, topic: battle.topic, category: battle.category });
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    setSaving(true);
    try {
      await updateBattle(battle.id, editData);
      setEditing(false);
      onRefresh();
    } catch (err) {
      alert(err instanceof Error ? err.message : "Failed to save");
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!confirm(`Delete battle #${battle.battleNumber}? This also deletes all votes for this battle.`)) return;
    try {
      await deleteBattle(battle.id);
      onRefresh();
    } catch (err) {
      alert(err instanceof Error ? err.message : "Failed to delete");
    }
  };

  return (
    <div className="border-b border-white/5 last:border-0">
      <div
        className="flex items-center gap-4 px-4 py-3 hover:bg-white/[0.02] cursor-pointer transition-colors"
        onClick={() => setExpanded(!expanded)}
      >
        <div className="w-5">
          {expanded ? <ChevronDown className="w-3.5 h-3.5 text-white/30" /> : <ChevronRight className="w-3.5 h-3.5 text-white/30" />}
        </div>
        <span className="text-xs font-mono text-white/40 w-10">#{battle.battleNumber}</span>
        <StatusBadge status={battle.status} />
        <span className="text-sm text-white flex-1 truncate">{battle.modelA} vs {battle.modelB}</span>
        <span className="text-[10px] text-white/20 font-display tracking-wider uppercase">{battle.category}</span>
        <span className="text-xs text-white/30 font-mono w-16 text-right">{battle.votesA + battle.votesB}v</span>
        <span className="text-xs text-white/20 w-20 text-right">R{battle.round}/{battle.maxRounds}</span>
      </div>
      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden"
          >
            <div className="px-4 pb-4 pl-9 space-y-3">
              <div className="bg-black/30 rounded-lg p-3 border border-white/5">
                <p className="text-[9px] font-display tracking-widest text-white/30 uppercase mb-1">Topic</p>
                {editing ? (
                  <input
                    value={editData.topic}
                    onChange={(e) => setEditData({ ...editData, topic: e.target.value })}
                    className="w-full bg-black/50 border border-white/10 rounded px-2 py-1 text-sm text-white focus:outline-none focus:border-primary/50"
                  />
                ) : (
                  <p className="text-sm text-white/70">{battle.topic}</p>
                )}
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-black/30 rounded-lg p-3 border border-white/5">
                  <p className="text-[9px] font-display tracking-widest text-white/30 uppercase mb-1">{battle.modelA} ({battle.votesA} votes)</p>
                  <p className="text-xs text-white/50 max-h-32 overflow-y-auto whitespace-pre-wrap">{battle.responseA?.slice(0, 500) ?? "No response yet"}</p>
                </div>
                <div className="bg-black/30 rounded-lg p-3 border border-white/5">
                  <p className="text-[9px] font-display tracking-widest text-white/30 uppercase mb-1">{battle.modelB} ({battle.votesB} votes)</p>
                  <p className="text-xs text-white/50 max-h-32 overflow-y-auto whitespace-pre-wrap">{battle.responseB?.slice(0, 500) ?? "No response yet"}</p>
                </div>
              </div>
              {editing && (
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <p className="text-[9px] font-display tracking-widest text-white/30 uppercase mb-1">Status</p>
                    <select
                      value={editData.status}
                      onChange={(e) => setEditData({ ...editData, status: e.target.value })}
                      className="w-full bg-black/50 border border-white/10 rounded px-2 py-1.5 text-sm text-white focus:outline-none focus:border-primary/50"
                    >
                      <option value="scheduled">Scheduled</option>
                      <option value="generating">Generating</option>
                      <option value="live">Live</option>
                      <option value="complete">Complete</option>
                    </select>
                  </div>
                  <div>
                    <p className="text-[9px] font-display tracking-widest text-white/30 uppercase mb-1">Category</p>
                    <input
                      value={editData.category}
                      onChange={(e) => setEditData({ ...editData, category: e.target.value })}
                      className="w-full bg-black/50 border border-white/10 rounded px-2 py-1 text-sm text-white focus:outline-none focus:border-primary/50"
                    />
                  </div>
                </div>
              )}
              <div className="flex items-center gap-2 text-xs text-white/20">
                <Clock className="w-3 h-3" />
                <span>Created: {new Date(battle.createdAt).toLocaleString()}</span>
                {battle.startedAt && <span>| Started: {new Date(battle.startedAt).toLocaleString()}</span>}
                {battle.completedAt && <span>| Completed: {new Date(battle.completedAt).toLocaleString()}</span>}
                {battle.winnerId && <span>| Winner: Side {battle.winnerId.toUpperCase()}</span>}
              </div>
              <div className="flex gap-2 pt-2">
                {editing ? (
                  <>
                    <Button size="sm" onClick={handleSave} disabled={saving} className="gap-1.5">
                      <Save className="w-3 h-3" />{saving ? "Saving..." : "Save"}
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => setEditing(false)} className="gap-1.5">
                      <X className="w-3 h-3" />Cancel
                    </Button>
                  </>
                ) : (
                  <>
                    <Button size="sm" variant="outline" onClick={() => setEditing(true)} className="gap-1.5">
                      <Edit3 className="w-3 h-3" />Edit
                    </Button>
                    <Button size="sm" variant="outline" onClick={handleDelete} className="gap-1.5 text-red-400 border-red-500/20 hover:bg-red-500/10">
                      <Trash2 className="w-3 h-3" />Delete
                    </Button>
                  </>
                )}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function OverviewTab({ data, onRefresh }: { data: DashboardData; onRefresh: () => void }) {
  const [triggering, setTriggering] = useState(false);
  const [seeding, setSeeding] = useState(false);
  const [actionMsg, setActionMsg] = useState("");

  const handleTrigger = async () => {
    setTriggering(true);
    try {
      const res = await triggerBattle();
      setActionMsg(res.message);
      onRefresh();
    } catch (err) {
      setActionMsg(err instanceof Error ? err.message : "Failed");
    } finally {
      setTriggering(false);
      setTimeout(() => setActionMsg(""), 4000);
    }
  };

  const handleSeed = async () => {
    setSeeding(true);
    try {
      const res = await seedBattle();
      setActionMsg(res.message);
      onRefresh();
    } catch (err) {
      setActionMsg(err instanceof Error ? err.message : "Failed");
    } finally {
      setSeeding(false);
      setTimeout(() => setActionMsg(""), 4000);
    }
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <StatCard label="Total Battles" value={data.battles.total} icon={Swords} color="text-violet-400" sub={`${data.battles.complete} complete`} />
        <StatCard label="Total Votes" value={data.votes.total} icon={Vote} color="text-emerald-400" sub={`${data.votes.last24h} in 24h`} />
        <StatCard label="Atlas IDs" value={data.profiles.total} icon={Users} color="text-blue-400" sub={`${data.profiles.newLast24h} new today`} />
        <StatCard label="Live Now" value={data.battles.live} icon={Zap} color={data.battles.live > 0 ? "text-red-400" : "text-white/20"} sub={`${data.battles.scheduled} scheduled`} />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        <div className="bg-[#0a0a0a] border border-white/5 rounded-xl p-4">
          <p className="text-[9px] font-display tracking-widest text-white/30 uppercase mb-3">Battle Pipeline</p>
          <div className="space-y-2">
            {[
              { label: "Scheduled", count: data.battles.scheduled, color: "bg-blue-500" },
              { label: "Generating", count: data.battles.generating, color: "bg-amber-500" },
              { label: "Live", count: data.battles.live, color: "bg-red-500" },
              { label: "Complete", count: data.battles.complete, color: "bg-emerald-500" },
            ].map((s) => (
              <div key={s.label} className="flex items-center gap-3">
                <span className={`w-2 h-2 rounded-full ${s.color}`} />
                <span className="text-xs text-white/50 flex-1">{s.label}</span>
                <span className="text-sm font-display font-bold text-white">{s.count}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-[#0a0a0a] border border-white/5 rounded-xl p-4">
          <p className="text-[9px] font-display tracking-widest text-white/30 uppercase mb-3">Quick Actions</p>
          <div className="space-y-2">
            <Button size="sm" className="w-full gap-2" onClick={handleTrigger} disabled={triggering}>
              <Play className="w-3 h-3" />{triggering ? "Triggering..." : "Trigger Next Battle"}
            </Button>
            <Button size="sm" variant="outline" className="w-full gap-2" onClick={handleSeed} disabled={seeding}>
              <Plus className="w-3 h-3" />{seeding ? "Seeding..." : "Seed New Battle"}
            </Button>
          </div>
          {actionMsg && (
            <p className="text-xs text-primary mt-2 flex items-center gap-1.5">
              <CheckCircle className="w-3 h-3" />{actionMsg}
            </p>
          )}
        </div>
      </div>

      <div className="bg-[#0a0a0a] border border-white/5 rounded-xl p-4">
        <p className="text-[9px] font-display tracking-widest text-white/30 uppercase mb-3">Recent Votes</p>
        {data.recentVotes.length === 0 ? (
          <p className="text-xs text-white/20">No votes yet</p>
        ) : (
          <div className="space-y-1">
            {data.recentVotes.slice(0, 10).map((v) => (
              <div key={v.id} className="flex items-center gap-3 py-1.5 border-b border-white/5 last:border-0">
                <span className="text-[10px] font-mono text-white/30">#{v.battleId}</span>
                <span className="text-xs text-white/60">@{v.atlasHandle}</span>
                <span className={`text-[9px] font-display tracking-wider uppercase px-1.5 py-0.5 rounded ${v.side === "a" ? "bg-emerald-500/10 text-emerald-400" : "bg-violet-500/10 text-violet-400"}`}>
                  Side {v.side.toUpperCase()}
                </span>
                <span className="text-[10px] text-white/20 ml-auto">{new Date(v.createdAt).toLocaleString()}</span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function BattlesTab() {
  const [battles, setBattles] = useState<AdminBattle[]>([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState<string>("");

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await getAdminBattles(1, statusFilter || undefined);
      setBattles(res.battles);
    } catch {
    } finally {
      setLoading(false);
    }
  }, [statusFilter]);

  useEffect(() => { load(); }, [load]);

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <p className="text-[9px] font-display tracking-widest text-white/30 uppercase flex-1">All Battles</p>
        <div className="flex gap-1.5">
          {["", "live", "generating", "scheduled", "complete"].map((s) => (
            <button
              key={s}
              onClick={() => setStatusFilter(s)}
              className={`text-[9px] font-display tracking-widest uppercase px-2.5 py-1 rounded-full border transition-colors ${statusFilter === s ? "border-primary/50 text-primary bg-primary/5" : "border-white/5 text-white/30 hover:text-white/50"}`}
            >
              {s || "All"}
            </button>
          ))}
        </div>
        <Button size="sm" variant="outline" onClick={load} className="gap-1.5">
          <RefreshCw className={`w-3 h-3 ${loading ? "animate-spin" : ""}`} />
        </Button>
      </div>
      <div className="bg-[#0a0a0a] border border-white/5 rounded-xl overflow-hidden">
        {loading ? (
          <div className="p-8 text-center text-white/20 text-sm">Loading...</div>
        ) : battles.length === 0 ? (
          <div className="p-8 text-center text-white/20 text-sm">No battles found</div>
        ) : (
          battles.map((b) => <BattleRow key={b.id} battle={b} onRefresh={load} />)
        )}
      </div>
    </div>
  );
}

function VotesTab() {
  const [voteList, setVoteList] = useState<AdminVote[]>([]);
  const [loading, setLoading] = useState(true);
  const [filterBattle, setFilterBattle] = useState("");

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const battleId = filterBattle ? parseInt(filterBattle, 10) : undefined;
      const res = await getAdminVotes(1, battleId);
      setVoteList(res.votes);
    } catch {
    } finally {
      setLoading(false);
    }
  }, [filterBattle]);

  useEffect(() => { load(); }, [load]);

  const handleDelete = async (id: number) => {
    if (!confirm("Delete this vote? Vote count on the battle will be decremented.")) return;
    try {
      await deleteVote(id);
      load();
    } catch (err) {
      alert(err instanceof Error ? err.message : "Failed");
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <p className="text-[9px] font-display tracking-widest text-white/30 uppercase flex-1">Vote Audit Log</p>
        <input
          type="text"
          placeholder="Filter by battle ID"
          value={filterBattle}
          onChange={(e) => setFilterBattle(e.target.value)}
          className="bg-black/50 border border-white/10 rounded-lg px-3 py-1.5 text-xs text-white placeholder:text-white/20 focus:outline-none focus:border-primary/50 w-36 font-mono"
        />
        <Button size="sm" variant="outline" onClick={load} className="gap-1.5">
          <RefreshCw className={`w-3 h-3 ${loading ? "animate-spin" : ""}`} />
        </Button>
      </div>
      <div className="bg-[#0a0a0a] border border-white/5 rounded-xl overflow-hidden">
        {loading ? (
          <div className="p-8 text-center text-white/20 text-sm">Loading...</div>
        ) : voteList.length === 0 ? (
          <div className="p-8 text-center text-white/20 text-sm">No votes found</div>
        ) : (
          <div className="divide-y divide-white/5">
            <div className="grid grid-cols-6 text-[9px] font-display tracking-widest text-white/20 uppercase px-4 py-2.5">
              <span>ID</span>
              <span>Battle</span>
              <span>User</span>
              <span>Side</span>
              <span>Time</span>
              <span className="text-right">Action</span>
            </div>
            {voteList.map((v) => (
              <div key={v.id} className="grid grid-cols-6 items-center px-4 py-2.5 hover:bg-white/[0.02]">
                <span className="text-xs font-mono text-white/30">{v.id}</span>
                <span className="text-xs font-mono text-white/40">#{v.battleId}</span>
                <span className="text-xs text-white/60">@{v.atlasHandle}</span>
                <span className={`text-[9px] font-display tracking-wider uppercase w-fit px-1.5 py-0.5 rounded ${v.side === "a" ? "bg-emerald-500/10 text-emerald-400" : "bg-violet-500/10 text-violet-400"}`}>
                  {v.side.toUpperCase()}
                </span>
                <span className="text-[10px] text-white/20">{new Date(v.createdAt).toLocaleString()}</span>
                <div className="text-right">
                  <button onClick={() => handleDelete(v.id)} className="text-red-400/50 hover:text-red-400 transition-colors">
                    <Trash2 className="w-3 h-3" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function ProfilesTab() {
  const [profiles, setProfiles] = useState<AdminProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [total, setTotal] = useState(0);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await getAdminProfiles();
      setProfiles(res.profiles);
      setTotal(res.total);
    } catch {
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const handleDelete = async (handle: string) => {
    if (!confirm(`Delete @${handle}? This also deletes all their votes.`)) return;
    try {
      await deleteProfile(handle);
      load();
    } catch (err) {
      alert(err instanceof Error ? err.message : "Failed");
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <p className="text-[9px] font-display tracking-widest text-white/30 uppercase flex-1">Atlas Profiles ({total})</p>
        <Button size="sm" variant="outline" onClick={load} className="gap-1.5">
          <RefreshCw className={`w-3 h-3 ${loading ? "animate-spin" : ""}`} />
        </Button>
      </div>
      <div className="bg-[#0a0a0a] border border-white/5 rounded-xl overflow-hidden">
        {loading ? (
          <div className="p-8 text-center text-white/20 text-sm">Loading...</div>
        ) : profiles.length === 0 ? (
          <div className="p-8 text-center text-white/20 text-sm">No profiles yet</div>
        ) : (
          <div className="divide-y divide-white/5">
            <div className="grid grid-cols-7 text-[9px] font-display tracking-widest text-white/20 uppercase px-4 py-2.5">
              <span>Handle</span>
              <span>Display</span>
              <span>Fav Model</span>
              <span>Votes</span>
              <span>Badges</span>
              <span>Joined</span>
              <span className="text-right">Action</span>
            </div>
            {profiles.map((p) => (
              <div key={p.id} className="grid grid-cols-7 items-center px-4 py-3 hover:bg-white/[0.02]">
                <span className="text-xs text-primary font-mono">@{p.handle}</span>
                <span className="text-xs text-white/60">{p.displayName}</span>
                <span className="text-xs text-white/40">{p.favoriteModel}</span>
                <span className="text-xs text-white/50 font-mono">{p.votesCount}</span>
                <div className="flex gap-1 flex-wrap">
                  {p.badges.map((b) => (
                    <span key={b} className="text-[8px] font-display tracking-wider uppercase px-1.5 py-0.5 rounded bg-primary/10 text-primary/60">{b}</span>
                  ))}
                </div>
                <span className="text-[10px] text-white/20">{new Date(p.joinedAt).toLocaleDateString()}</span>
                <div className="text-right">
                  <button onClick={() => handleDelete(p.handle)} className="text-red-400/50 hover:text-red-400 transition-colors">
                    <Trash2 className="w-3 h-3" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function ActivityTab() {
  const [activity, setActivity] = useState<ActivityData | null>(null);
  const [days, setDays] = useState(7);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await getActivity(days);
      setActivity(res);
    } catch {
    } finally {
      setLoading(false);
    }
  }, [days]);

  useEffect(() => { load(); }, [load]);

  const renderChart = (data: Array<{ day: string; total: number }>, color: string, label: string) => {
    if (data.length === 0) return <p className="text-xs text-white/20 py-4">No data for this period</p>;
    const max = Math.max(...data.map((d) => d.total), 1);
    return (
      <div className="space-y-1">
        <p className="text-[9px] font-display tracking-widest text-white/30 uppercase mb-2">{label}</p>
        {data.map((d, i) => (
          <div key={i} className="flex items-center gap-2">
            <span className="text-[9px] text-white/20 w-16 shrink-0 font-mono">{new Date(d.day).toLocaleDateString("en-US", { month: "short", day: "numeric" })}</span>
            <div className="flex-1 h-4 bg-white/5 rounded-full overflow-hidden">
              <div className={`h-full ${color} rounded-full transition-all`} style={{ width: `${(d.total / max) * 100}%` }} />
            </div>
            <span className="text-xs text-white/40 font-mono w-8 text-right">{d.total}</span>
          </div>
        ))}
      </div>
    );
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <p className="text-[9px] font-display tracking-widest text-white/30 uppercase flex-1">Activity Analytics</p>
        <div className="flex gap-1.5">
          {[7, 14, 30].map((d) => (
            <button
              key={d}
              onClick={() => setDays(d)}
              className={`text-[9px] font-display tracking-widest uppercase px-2.5 py-1 rounded-full border transition-colors ${days === d ? "border-primary/50 text-primary bg-primary/5" : "border-white/5 text-white/30 hover:text-white/50"}`}
            >
              {d}d
            </button>
          ))}
        </div>
        <Button size="sm" variant="outline" onClick={load} className="gap-1.5">
          <RefreshCw className={`w-3 h-3 ${loading ? "animate-spin" : ""}`} />
        </Button>
      </div>
      {loading ? (
        <div className="p-8 text-center text-white/20 text-sm">Loading...</div>
      ) : activity ? (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-[#0a0a0a] border border-white/5 rounded-xl p-4">
            {renderChart(activity.dailyVotes, "bg-emerald-500/60", "Daily Votes")}
          </div>
          <div className="bg-[#0a0a0a] border border-white/5 rounded-xl p-4">
            {renderChart(activity.dailyBattles, "bg-violet-500/60", "Daily Battles")}
          </div>
          <div className="bg-[#0a0a0a] border border-white/5 rounded-xl p-4">
            {renderChart(activity.dailySignups, "bg-blue-500/60", "Daily Signups")}
          </div>
        </div>
      ) : null}
    </div>
  );
}

export function Admin() {
  const [authed, setAuthed] = useState(false);
  const [activeTab, setActiveTab] = useState<"overview" | "battles" | "votes" | "profiles" | "activity">("overview");
  const [dashboard, setDashboard] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const saved = localStorage.getItem("admin_key");
    if (saved) {
      setAdminKey(saved);
      getDashboard()
        .then(() => setAuthed(true))
        .catch(() => localStorage.removeItem("admin_key"));
    }
  }, []);

  const loadDashboard = useCallback(async () => {
    setLoading(true);
    try {
      const data = await getDashboard();
      setDashboard(data);
    } catch {
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (authed) loadDashboard();
  }, [authed, loadDashboard]);

  if (!authed) return <AdminLogin onLogin={() => setAuthed(true)} />;

  const tabs = [
    { id: "overview" as const, label: "Overview", icon: BarChart3 },
    { id: "battles" as const, label: "Battles", icon: Swords },
    { id: "votes" as const, label: "Votes", icon: Vote },
    { id: "profiles" as const, label: "Profiles", icon: Users },
    { id: "activity" as const, label: "Activity", icon: Activity },
  ];

  const handleLogout = () => {
    localStorage.removeItem("admin_key");
    setAdminKey("");
    setAuthed(false);
  };

  return (
    <div className="w-full pt-20 pb-20">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-primary/10 border border-primary/30 flex items-center justify-center">
              <Shield className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h1 className="text-xl font-display font-bold text-white">Admin Control Center</h1>
              <p className="text-[10px] font-display tracking-widest text-white/30 uppercase">Atlas Arena Management</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Button size="sm" variant="outline" onClick={loadDashboard} disabled={loading} className="gap-1.5">
              <RefreshCw className={`w-3 h-3 ${loading ? "animate-spin" : ""}`} />Refresh
            </Button>
            <Button size="sm" variant="outline" onClick={handleLogout} className="gap-1.5 text-white/30">
              Logout
            </Button>
          </div>
        </div>

        <div className="flex gap-1.5 mb-6 border-b border-white/5 pb-4">
          {tabs.map((t) => (
            <button
              key={t.id}
              onClick={() => setActiveTab(t.id)}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-display tracking-wider uppercase transition-colors ${activeTab === t.id ? "bg-primary/10 text-primary border border-primary/30" : "text-white/30 hover:text-white/50 border border-transparent"}`}
            >
              <t.icon className="w-3.5 h-3.5" />
              {t.label}
            </button>
          ))}
        </div>

        {activeTab === "overview" && dashboard && <OverviewTab data={dashboard} onRefresh={loadDashboard} />}
        {activeTab === "overview" && !dashboard && <div className="p-8 text-center text-white/20">Loading...</div>}
        {activeTab === "battles" && <BattlesTab />}
        {activeTab === "votes" && <VotesTab />}
        {activeTab === "profiles" && <ProfilesTab />}
        {activeTab === "activity" && <ActivityTab />}
      </div>
    </div>
  );
}
