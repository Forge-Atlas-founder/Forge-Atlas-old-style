import { useState } from "react";
import { motion } from "framer-motion";
import { ShoppingBag, Code, Package, Layers, ArrowRight, Star, ExternalLink, Terminal, Cpu, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";

const CATEGORIES = [
  { icon: Code, label: "API Wrappers", count: 12 },
  { icon: Package, label: "Modules", count: 8 },
  { icon: Layers, label: "Multi-Platform", count: 6 },
  { icon: Terminal, label: "CLI Tools", count: 4 },
  { icon: Cpu, label: "Infrastructure", count: 3 },
];

const FEATURED_TOOLS = [
  {
    name: "UnifiedAI SDK",
    tag: "API Wrapper",
    desc: "One SDK to call GPT, Claude, Gemini, and Llama with unified response schemas and automatic fallbacks. Supports streaming, function calling, and cost tracking.",
    stars: 4.9,
    reviews: 87,
    price: "Free",
    badge: "Staff Pick",
    tags: ["TypeScript", "Python", "Node.js"],
    downloads: "12.4k",
  },
  {
    name: "PromptForge",
    tag: "Module",
    desc: "Structured prompt management with version control, A/B testing hooks, and real-time token cost estimation across providers.",
    stars: 4.7,
    reviews: 54,
    price: "$19/mo",
    badge: "New",
    tags: ["TypeScript", "CLI"],
    downloads: "3.2k",
  },
  {
    name: "StreamBridge",
    tag: "Multi-Platform",
    desc: "Normalize streaming responses from any AI provider into a single event format. Works with Next.js, Express, FastAPI, and Cloudflare Workers.",
    stars: 4.8,
    reviews: 41,
    price: "Free",
    badge: null,
    tags: ["Node.js", "Python", "Workers"],
    downloads: "8.7k",
  },
  {
    name: "AIRouter",
    tag: "API Wrapper",
    desc: "Intelligent request routing that selects the best AI model based on cost, latency, and task type. Drop-in replacement for direct API calls.",
    stars: 4.6,
    reviews: 32,
    price: "$9/mo",
    badge: "Popular",
    tags: ["TypeScript", "Go"],
    downloads: "5.1k",
  },
  {
    name: "ContextKit",
    tag: "Module",
    desc: "Token-aware context window management. Automatically compresses, summarizes, and prioritizes message history to stay within model limits.",
    stars: 4.5,
    reviews: 28,
    price: "Free",
    badge: null,
    tags: ["TypeScript", "Python"],
    downloads: "6.9k",
  },
  {
    name: "EvalSuite",
    tag: "Multi-Platform",
    desc: "Automated evaluation framework for AI outputs. Score responses on accuracy, tone, safety, and consistency. Built for CI/CD pipelines.",
    stars: 4.4,
    reviews: 19,
    price: "$29/mo",
    badge: "Coming Soon",
    tags: ["Python", "CLI", "GitHub Actions"],
    downloads: "1.8k",
  },
];

export function Market() {
  const [activeCategory, setActiveCategory] = useState<string | null>(null);

  return (
    <div className="w-full pt-20">

      <section className="py-24 px-6 border-b border-white/5 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-primary/4 rounded-full blur-[160px] pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-[300px] h-[300px] bg-primary/3 rounded-full blur-[120px] pointer-events-none" />
        <div className="max-w-4xl mx-auto text-center relative z-10">
          <motion.div
            initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}
            className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-white/10 bg-white/5 mb-8"
          >
            <ShoppingBag className="w-3 h-3 text-muted-foreground" />
            <span className="text-xs font-display tracking-[0.2em] text-muted-foreground uppercase">Coming Soon · Early Access Open</span>
          </motion.div>
          <motion.h1
            initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
            className="text-5xl md:text-7xl font-display font-bold uppercase text-white leading-tight mb-4"
          >
            The Market
          </motion.h1>
          <motion.p
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.2 }}
            className="text-lg text-muted-foreground max-w-2xl mx-auto mb-4"
          >
            Curated AI tools built by builders who actually use them. No fluff. No abandoned repos. Everything listed ships.
          </motion.p>
          <motion.p
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.25 }}
            className="text-sm text-white/30 max-w-lg mx-auto mb-10"
          >
            Every tool goes through manual review before listing. We test it, read the code, and verify it solves a real problem.
          </motion.p>
          <motion.div
            initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}
            className="flex flex-col sm:flex-row gap-4 justify-center"
          >
            <Button size="lg">Browse Tools</Button>
            <Button size="lg" variant="outline">Submit Your Tool</Button>
          </motion.div>
        </div>
      </section>

      <section className="py-20 border-b border-white/5 px-6">
        <div className="max-w-5xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-8 md:divide-x divide-white/5">
          {[
            { value: "33", label: "Tools Listed" },
            { value: "24k+", label: "Downloads" },
            { value: "4.7", label: "Avg Rating" },
            { value: "100%", label: "Reviewed" },
          ].map((stat, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 16 }} whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }} transition={{ delay: i * 0.08 }}
              className="text-center"
            >
              <div className="text-3xl md:text-4xl font-display font-bold text-primary mb-1">{stat.value}</div>
              <div className="text-xs font-display tracking-[0.25em] text-muted-foreground uppercase">{stat.label}</div>
            </motion.div>
          ))}
        </div>
      </section>

      <div className="border-b border-white/5 bg-card/50 py-5 px-6">
        <div className="max-w-7xl mx-auto flex flex-wrap gap-3 justify-center md:justify-start">
          <button
            onClick={() => setActiveCategory(null)}
            className={`flex items-center gap-2 px-4 py-2 rounded-full border transition-all text-xs font-display tracking-widest uppercase ${!activeCategory ? "border-primary/50 text-primary bg-primary/10" : "border-white/10 text-muted-foreground hover:border-primary/30 hover:text-white"}`}
          >
            <Zap className="w-3.5 h-3.5" /> All
          </button>
          {CATEGORIES.map((cat, i) => (
            <button
              key={i}
              onClick={() => setActiveCategory(cat.label)}
              className={`flex items-center gap-2 px-4 py-2 rounded-full border transition-all text-xs font-display tracking-widest uppercase ${activeCategory === cat.label ? "border-primary/50 text-primary bg-primary/10" : "border-white/10 text-muted-foreground hover:border-primary/30 hover:text-white"}`}
            >
              <cat.icon className="w-3.5 h-3.5" />
              {cat.label}
              <span className="text-[10px] bg-white/5 px-1.5 py-0.5 rounded-full">{cat.count}</span>
            </button>
          ))}
        </div>
      </div>

      <section className="py-16 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between mb-10">
            <h2 className="text-2xl font-display font-bold text-white uppercase">Featured Tools</h2>
            <Button variant="ghost" size="sm" className="text-muted-foreground">
              View All <ArrowRight className="ml-2 w-4 h-4" />
            </Button>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
            {FEATURED_TOOLS.filter(tool => !activeCategory || tool.tag === activeCategory || (activeCategory === "Multi-Platform" && tool.tag === "Multi-Platform")).map((tool, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.06 }}
                className="bg-card border border-white/5 rounded-2xl p-6 hover:border-primary/20 hover:shadow-[0_0_30px_rgba(212,168,67,0.05)] transition-all duration-300 group flex flex-col"
              >
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <div className="flex items-center gap-2 mb-1.5">
                      <span className="text-[10px] font-display tracking-widest text-muted-foreground uppercase">{tool.tag}</span>
                      {tool.badge && (
                        <span className={`text-[9px] font-display tracking-widest px-2 py-0.5 rounded-full uppercase ${tool.badge === "Staff Pick" ? "bg-primary/20 text-primary border border-primary/30" : tool.badge === "Coming Soon" ? "bg-white/5 text-white/30 border border-white/10" : "bg-white/5 text-white/50 border border-white/10"}`}>
                          {tool.badge}
                        </span>
                      )}
                    </div>
                    <h3 className="text-lg font-display font-bold text-white">{tool.name}</h3>
                  </div>
                  <span className="text-primary font-display font-bold text-sm">{tool.price}</span>
                </div>

                <p className="text-sm text-muted-foreground leading-relaxed mb-4 flex-1">{tool.desc}</p>

                <div className="flex flex-wrap gap-1.5 mb-5">
                  {tool.tags.map((tag) => (
                    <span key={tag} className="text-[10px] font-display tracking-widest text-white/40 bg-white/5 px-2 py-1 rounded uppercase">
                      {tag}
                    </span>
                  ))}
                </div>

                <div className="flex items-center justify-between pt-4 border-t border-white/5">
                  <div className="flex items-center gap-3">
                    <div className="flex items-center gap-1">
                      <Star className="w-3 h-3 text-primary fill-primary" />
                      <span className="text-sm font-display font-bold text-white">{tool.stars}</span>
                      <span className="text-xs text-muted-foreground">({tool.reviews})</span>
                    </div>
                    <span className="text-[10px] text-white/20">·</span>
                    <span className="text-[10px] font-display tracking-wide text-muted-foreground">{tool.downloads} downloads</span>
                  </div>
                  <button className="flex items-center gap-1.5 text-xs font-display tracking-widest text-primary uppercase hover:gap-2.5 transition-all group/btn">
                    View <ExternalLink className="w-3 h-3" />
                  </button>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-24 border-t border-white/5 px-6">
        <div className="max-w-5xl mx-auto">
          <div className="bg-card border border-white/5 rounded-2xl overflow-hidden">
            <div className="grid md:grid-cols-2">
              <div className="p-10 md:p-14 flex flex-col justify-center">
                <p className="text-primary font-display tracking-[0.3em] text-xs uppercase mb-4">For Builders</p>
                <h2 className="text-3xl md:text-4xl font-display font-bold text-white uppercase mb-4 leading-tight">
                  Built something<br />worth using?
                </h2>
                <p className="text-muted-foreground mb-8 leading-relaxed">
                  If you've built an AI wrapper, module, or tool that solves a real problem — we want it listed. No listing fees during early access. We review everything within 48 hours.
                </p>
                <div className="space-y-3 mb-8">
                  {[
                    "Manual code review before listing",
                    "Featured placement for top-rated tools",
                    "Direct analytics on views, clicks, and installs",
                  ].map((item) => (
                    <div key={item} className="flex items-center gap-3">
                      <div className="w-1 h-1 rounded-full bg-primary" />
                      <span className="text-sm text-white/60">{item}</span>
                    </div>
                  ))}
                </div>
                <div>
                  <Button size="lg">Submit Your Tool <ArrowRight className="ml-2 w-5 h-5" /></Button>
                </div>
              </div>
              <div className="bg-[#0d0d0d] p-10 md:p-14 border-t md:border-t-0 md:border-l border-white/5 flex flex-col justify-center">
                <p className="text-primary font-display tracking-[0.3em] text-xs uppercase mb-4">The Standard</p>
                <div className="space-y-6">
                  {[
                    { num: "01", text: "Every tool must solve a real problem. No demos, no toys." },
                    { num: "02", text: "Active maintenance required. Abandoned repos get delisted." },
                    { num: "03", text: "Documentation that a human actually wrote and tested." },
                    { num: "04", text: "Honest pricing. Free means free. No bait-and-switch." },
                  ].map((rule) => (
                    <div key={rule.num} className="flex gap-4 items-start">
                      <span className="text-xl font-display font-bold text-primary/20">{rule.num}</span>
                      <p className="text-sm text-white/70 leading-relaxed">{rule.text}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

    </div>
  );
}
